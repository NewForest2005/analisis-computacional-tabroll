"""Réplica de la celda de la línea (voz aguda) para probar cambios sin correr el cuaderno."""
import json, glob, textwrap, time
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
from scipy.ndimage import uniform_filter1d, median_filter, maximum_filter1d
from scipy.signal import find_peaks
from comun import *
B='/ruta/de/trabajo/h3/base/'
C=B+'src/tabroll/cells/'
ns=dict(np=np, sliding_window_view=sliding_window_view, uniform_filter1d=uniform_filter1d, median_filter=median_filter,
        maximum_filter1d=maximum_filter1d, find_peaks=find_peaks)
for f in ('stft_mag','pitch_salience','harmonic_part','viterbi_pitch','stereo_salience','add_guitar_stem','extract_notes','guitar_gate','drop_loose_notes'):
    exec(open(C+f+'.py').read(), ns)
nb=json.load(open(B+'notebooks/Tabroll_Angine_de_Poitrine.ipynb'))
src=''.join(nb['cells'][125]['source'])
exec(textwrap.dedent(src.split('M = stft_mag')[0].split('if True:',1)[1]), ns)
SR, NF, HOP = 22050, 4096, 512
_base={}
def base(song):
    if song in _base: return _base[song]
    J,cyc,hi,lo,al=load(song)
    st=np.fromfile(f'{song}.mix.f32',np.float32).reshape(-1,2).T
    y=st.mean(0); n=len(y)
    stem=np.fromfile(f'{song}.gtr.f32',np.float32); stem=np.pad(stem,(0,max(n-len(stem),0)))[:n]
    M=ns['stft_mag'](y,NF,HOP); S,cand=ns['pitch_salience'](M,SR,NF)
    Sn=ns['stereo_salience'](S,M,st,cand,SR,NF,HOP,True,gamma=0.0)
    Sn=ns['add_guitar_stem'](Sn,S,stem,cand,SR,NF,HOP,gamma=0.0)
    _base[song]=dict(J=J,cyc=cyc,lo=lo,stem=stem,S=S,cand=cand,Sn=Sn,M=M,st=st)
    return _base[song]
def notas_agudas(song, floor=47.0, atr_sd=12.0, Sn=None, cand=None, post=None):
    b=base(song); J=b['J']; cyc=b['cyc']
    Sn=b['Sn'] if Sn is None else Sn; cand=b['cand'] if cand is None else cand
    ish=cand>=floor
    Snote=Sn[ish].max(axis=0)
    cons=ns['cycle_consensus'](Sn[ish],cyc,SR,HOP)
    base_line=ns['viterbi_pitch'](cons,cand[ish],np.percentile(Snote,55))
    reg=float(np.nanmedian(base_line)) if np.isfinite(base_line).any() else float(np.median(cand[ish]))
    atr=0.7+0.3*np.exp(-0.5*((cand[ish]-reg)/atr_sd)**2)
    mel=ns['viterbi_pitch'](cons*atr[:,None],cand[ish],np.percentile(Snote,55))
    gate=ns['guitar_gate'](b['stem'],len(mel),HOP,SR)
    on=np.array(J['onsets_h_s'])
    raw=ns['extract_notes'](np.where(gate,mel,np.nan),Snote,on,SR,HOP,J['off'],50)
    raw=ns['drop_loose_notes'](raw,cyc)
    if post: raw=post(raw, mel, Sn[ish], cand[ish])
    return raw, mel
if __name__=='__main__':
    for song in SONGS:
        t=time.time(); raw,_=notas_agudas(song)
        J,cyc,hi,lo,al=load(song)
        print(song, f'{time.time()-t:.0f}s', 'réplica',len(raw),'notas vs guardadas',len(hi),'| F réplica',evaluar(song,raw,lo)['principal'],'guardada',evaluar(song,hi,lo)['principal'])
