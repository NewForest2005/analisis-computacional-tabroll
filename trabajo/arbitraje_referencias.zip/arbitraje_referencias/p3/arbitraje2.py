"""Segunda ronda: tres posiciones dudosas (elección de ¼, a ciegas) y cuatro correcciones candidatas (versiones a ciegas)."""
import subprocess, random, csv
from pathlib import Path
from comun import *
import tabroll.evaluation.melodia as MM
SR=22050; OUT='/ruta/de/trabajo/arbitraje2/'
BASE=Path('refs_cons').resolve()
rng=random.Random(20261114)
def ref_al(song, d):
    MM.REFS=Path(d).resolve(); r=MM.reference(song); al=MM.Alignment(song, ref=r); MM.REFS=BASE; return al
_sh={}
def shift(song):
    if song not in _sh:
        J,cyc,hi,lo,al=load(song); al=ref_al(song,BASE); gu=MM.mapped(al,al.ref['guitars']); _sh[song]=MM.calib(MM.top_line(gu),hi)
    return _sh[song]
def notas(song, d, parts, A0, dur, todo=False):
    al=ref_al(song,d); sh=shift(song)
    if todo: al.deleted[:]=False          # para sintetizar: también lo que la alineación marca como borrado
    return [(n['t']+sh,n['te']+sh,n['p'],n['part']) for n in MM.mapped(al,parts,known_only=False) if A0-1<=n['t']+sh<A0+dur]
def synth(notes, t0, dur, off):                       # más staccato que en la primera ronda
    y=np.zeros(int(dur*SR),np.float32)
    for t,te,p,*_ in notes:
        a=int((t-t0)*SR); b=int((t+max(0.06,min(0.75*(te-t),te-t-0.03))-t0)*SR)
        if b<=0 or a>=len(y): continue
        a,b=max(a,0),min(b,len(y)); tt=np.arange(b-a)/SR; f=440*2**((p+off-69)/12)
        w=sum(np.sin(2*np.pi*h*f*tt)/h for h in (1,2,3,4)); env=np.minimum(1,tt/0.008)*np.exp(-tt*5.0)*np.minimum(1,(b-a-np.arange(b-a))/(0.01*SR))
        y[a:b]+=0.25*w*env
    return y
X={}
def audio(song):
    if song not in X: X[song]=np.fromfile(f'{song}.gtr.f32',np.float32)
    return X[song]
ORDEN={}
def clip(song, A0, dur, variantes, archivo, clave_orden=None):
    """variantes: lista de (nombre, notas en tiempo de audio). Las ordena al azar y escribe el mp3."""
    J=load(song)[0]; x=audio(song)
    L=x[int(A0*SR):int((A0+dur)*SR)]; L=L/(np.abs(L).max()+1e-9)*0.8
    firmas=[tuple((round(t,2),round(q,2)) for t,te,q,*_ in v) for _,v in variantes]
    assert len(set(firmas))==len(firmas), (archivo,'versiones iguales')
    orden=list(range(len(variantes))); rng.shuffle(orden)
    if clave_orden is not None and len(variantes)==2:
        if clave_orden in ORDEN: orden=ORDEN[clave_orden][::-1]
        ORDEN[clave_orden]=orden
    partes=[]
    for i in orden:
        R=synth(variantes[i][1],A0,len(L)/SR,J['off']); R=R/(np.abs(R).max()+1e-9)*0.6
        partes += [np.stack([L,R[:len(L)]],1), np.zeros((int(0.8*SR),2))]
    st=np.concatenate(partes[:-1]).astype(np.float32)
    subprocess.run(['ffmpeg','-y','-v','error','-f','f32le','-ar',str(SR),'-ac','2','-i','-','-b:a','160k',OUT+archivo],input=st.tobytes(),check=True)
    return [variantes[i][0] for i in orden]
items=[]
FIJ={'C1':'el acorde largo, hacia los 2 s','C2':'todo el fragmento','C3':'hacia los 3 s','C4':'todo el fragmento','C5':'hacia los 2 s'}
# ---------- parte 1: posiciones dudosas de Sarniezz (P1 13, 25, 28) y controles
song='sarniezz'
import importlib.util
spec=importlib.util.spec_from_file_location('s',str(BASE/'sarniezz_partitura.py')); S=importlib.util.module_from_spec(spec); spec.loader.exec_module(S)
al=ref_al(song,BASE); sh=shift(song); secs=al.ref['sections']
tl=S.timeline(); starts=np.cumsum([0.0]+[n*e for t0,n,e,kn,nm in tl])
def ocurrencias(pos, pitch_w):
    out=[]
    for k,(t0,n,e,kn,nm) in enumerate(tl):
        if not kn or not nm.startswith('Frase 1'): continue
        reps=n//48
        for r in range(reps):
            ts=starts[k]+(r*48+pos)*e
            out.append((float(al.t(ts))+sh, pitch_w-12, nm))
    return out
anteriores=[81.95,86.62,121.23,96.39,120.89,192.81,103.80,87.25,131.57,189.53,93.97]
for pos,w,tipo in ((13,S.P('Fs5'),'caso'),(25,S.P('Aq4'),'caso'),(28,S.P('Aq4'),'caso'),(42,S.P('Ct5'),'control')):
    occ=[o for o in ocurrencias(pos,w) if min(abs(o[0]-a) for a in anteriores)>1.0]
    pick=[occ[i] for i in sorted(set(np.linspace(0,len(occ)-1,3 if tipo=='caso' else 1).round().astype(int)))]
    for T,p,nm in pick: items.append(('posición',song,f'P1 pos {pos}',T,p))
# control de Mata Zyklek: un Fa del «Corte» (la partitura quedó confirmada en la primera ronda)
items.append(('posición','mata_zyklek','control Fa3 del Corte',None,None))
rng.shuffle(items)
clave=[]; filas=[]; k=0
for tipo,song,nombre,T,p in items:
    k+=1
    if song=='mata_zyklek':
        J,cyc,hi,lo,alm=load(song); alm=ref_al(song,BASE); shm=shift(song); lead=MM.lead_line(alm,song)
        cand=[n for n in lead if abs(n['p']-53.0)<0.01 and 'Corte' in alm.ref['sections'][n['sec']][2]]
        n=cand[len(cand)//2]; T=n['t']+shm; p=n['p']; parts=('G3',)
    else:
        parts=('G1',)
    A0=T-2.0; dur=5.0
    base=notas(song,BASE,parts,A0,dur)
    hit=[1 for t,te,q,part in base if abs(t-T)<0.02 and abs(q-p)<0.01]
    assert len(hit)==1, (nombre,T,p,len(hit))
    vs=[]
    for dlt in (0.0,0.5,-0.5):
        vs.append((f'{dlt:+.1f}',[(t,te,(q+dlt if abs(t-T)<0.02 and abs(q-p)<0.01 else q)) for t,te,q,part in base]))
    archivo=f'{k:02d}_{ {"sarniezz":"sar","mata_zyklek":"mata"}[song]}_{int(T//60)}m{int(T%60):02d}s.mp3'
    orden=clip(song,A0,dur,vs,archivo)
    clave.append(dict(archivo=archivo,parte='1',que=nombre,cancion=song,t_audio=round(T,2),repeticiones=';'.join(orden)))
    filas.append(dict(archivo=archivo,cancion={'sarniezz':'Sarniezz','mata_zyklek':'Mata Zyklek'}[song],minuto=f'{int(T//60)}:{int(T%60):02d}',
                      parte='1',fijarse='la nota de los 2 s',eleccion='',seguridad='',comentario=''))
# ---------- parte 2: correcciones candidatas
cands=[]
# C1: acorde largo de la frase 1 (posición 19), dos apariciones
for pos_t in [o for o in ocurrencias(19,S.P('Fs5'))][1::5][:2]:
    T=pos_t[0]; A0=T-2.0
    cands.append(('C1 acorde pos 19','sarniezz',A0,5.0,[('partitura',BASE),('Do#+Sol',Path('var_sar_acB')),('Do#+Re+Sol',Path('var_sar_acC'))],('G1',),None))
# C2: Fabienk «Corrido otra vez»: con o sin las notas de la guitarra 1 intercaladas
for T in (78.21, 74.9):
    cands.append(('C2 notas de la guitarra 1 en «Corrido otra vez»','fabienk',T-2.0,5.0,[('partitura',None),('sin la guitarra 1',None)],('G1','G2'),'fab'))
# C3: Mata Zyklek compás 120: con o sin Re antes del silencio (dos veces, en orden distinto)
cands.append(('C3 Re antes del silencio (c. 120)','mata_zyklek',120,6.0,[('partitura',BASE),('con Re',Path('var_mata_D'))],('G3',),'mata'))
cands.append(('C3 Re antes del silencio (c. 64)','mata_zyklek',64,6.0,[('partitura',BASE),('con Re',Path('var_mata_D64'))],('G3',),'mata'))
# C4: Sarniezz 3:05-3:12: fase de la frase 2 de la guitarra 2
for T in (186.0, 190.5):
    cands.append(('C4 fase de la frase 2 (guitarra 2)','sarniezz',T-2.0,6.0,[('partitura',BASE),('3 corcheas antes',Path('var_sar_p2_mas3')),('3 corcheas después',Path('var_sar_p2_menos3'))],('G1','G2'),None))
# C5: Fabienk, el lick que las dos guitarras tocan al unísono (Z pos 3 de la guitarra 1 con W pos 3 de la guitarra 2)
for T in (51.96, 81.48):
    cands.append(('C5 lick al unísono (Z pos 3, guitarra 1)','fabienk',T-2.0,5.0,
                  [('actual: guitarra 1 Re#, guitarra 2 Re#+¼',BASE),('las dos Re#+¼',Path('var_fab_Z')),('las dos Re#',Path('../h3/base/references'))],('G1','G2'),None))
rng.shuffle(cands)
for nombre,song,A0,dur,vers,parts,esp in cands:
    k+=1
    if esp=='mata':
        alm=ref_al('mata_zyklek',BASE); shm=shift('mata_zyklek'); q=60/186
        tb=(A0-1)*5*q; A0=float(alm.t(tb))+shm-3.0
    vs=[]
    for vn,d in vers:
        if esp=='fab':
            base=notas(song,BASE,parts,A0,dur)
            al_f=ref_al(song,BASE); lead=MM.lead_line(al_f,song); shf=shift(song)
            L=[(n['t']+shf,n['te']+shf,n['p'],n['part']) for n in lead if A0-1<=n['t']+shf<A0+dur]
            vs.append((vn, L if vn=='partitura' else [n for n in L if n[3]!='G1']))
        else:
            vs.append((vn,notas(song,d,parts,A0,dur,todo=(esp=='mata'))))
    archivo=f'{k:02d}_{ {"sarniezz":"sar","mata_zyklek":"mata","fabienk":"fab"}[song]}_{int((A0+2)//60)}m{int((A0+2)%60):02d}s.mp3'
    orden=clip(song,A0,dur,vs,archivo,clave_orden=nombre[:2])
    for (vn,v) in vs: print('   ',archivo,vn,len(v),'notas')
    clave.append(dict(archivo=archivo,parte='2',que=nombre,cancion=song,t_audio=round(A0+2,2),repeticiones=';'.join(orden)))
    filas.append(dict(archivo=archivo,cancion={'sarniezz':'Sarniezz','mata_zyklek':'Mata Zyklek','fabienk':'Fabienk'}[song],
                      minuto=f'{int((A0+2)//60)}:{int((A0+2)%60):02d}',parte='2',fijarse=FIJ[nombre[:2]],eleccion='',seguridad='',comentario=''))
with open('clave_arbitraje2.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(clave[0])); w.writeheader(); w.writerows(clave)
with open(OUT+'respuestas2.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(filas[0]),delimiter=';'); w.writeheader(); w.writerows(filas)
for c in clave: print(c)
