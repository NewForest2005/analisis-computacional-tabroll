"""Transcripción de las pistas sintetizadas de la partitura (un instrumento limpio por pista) en 24-EDO."""
import sys, json, numpy as np
from linea import ns, SR, NF, HOP
for f in ('mel_bank','onset_envelopes','detect_onsets'):
    exec(open('/ruta/de/trabajo/h3/base/src/tabroll/cells/'+f+'.py').read(), ns)
from refina import stft, fine_pitch
N=['C','C+','C#','C#+','D','D+','D#','D#+','E','E+','F','F+','F#','F#+','G','G+','G#','G#+','A','A+','A#','A#+','B','B+']
nm=lambda p: N[int(round(2*p))%24]+str(int(round(2*p))//24-1)
def transcribe(x, lo=26.0, hi=100.0, band=0, height=0.3):
    M=ns['stft_mag'](x,NF,HOP); S,cand=ns['pitch_salience'](M,SR,NF)
    keep=(cand>=lo)&(cand<=hi); S=S[keep]; cand=cand[keep]
    Smax=S.max(axis=0); line=ns['viterbi_pitch'](S,cand,np.percentile(Smax,30))
    on=ns['detect_onsets'](ns['onset_envelopes'](x,SR)[band],SR/256,height=height,win=0.15)
    notes=ns['extract_notes'](line,Smax,on,SR,HOP,0.0,50)
    return notes
if __name__=='__main__':
    sys.path.insert(0,'/ruta/de/trabajo/h3/base/src')
    from tabroll.reference.guitarpro import parse_gp
    gp=parse_gp('/ruta/de/trabajo/h3/base/Angine_de_Poitrine-Yor_Zarad.gp')
    for part,track,lo,hi in (('Guitar_I','E.Guitar I',40,100),('Bass','E.Bass',26,60)):
        x=np.fromfile(f'yz_{part}.f32',np.float32)
        notes=[n for n in transcribe(x[:int(40*SR)],lo,hi,band=1 if part=='Bass' else 0) if n[0]<40]
        X=stft(x[:int(40*SR)]); fine=fine_pitch(notes,X,0.0)
        ref=[e for t in gp['tracks'] if t['name']==track for e in t['events']]
        refp=[e['pitch']['midi']+e['pitch']['bend_destination_value']/50 for e in sorted(ref,key=lambda e:e['onset_beats'])]
        print('==',part,'| primeras notas transcritas (t, altura, desviación fina en cents):')
        print('  ',' '.join(f'{a:.2f}:{nm(p)}({100*(f-p):+.0f})' for (a,b,p),f in zip(notes[:24],fine[:24])))
        print('   extracto .gp (altura con bend final):',' '.join(nm(p) for p in refp[:24]))
        dev=100*np.abs(fine-np.array([n[2] for n in notes]))
        print(f'   desviación fina: mediana {np.nanmedian(dev):.1f} cents, p95 {np.nanpercentile(dev,95):.1f} | notas de ¼ de tono: {sum(1 for n in notes if round(2*n[2])%2)} de {len(notes)}')
