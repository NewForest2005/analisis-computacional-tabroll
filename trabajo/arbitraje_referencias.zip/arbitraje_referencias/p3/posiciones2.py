from comun import *
from collections import Counter
import importlib.util
N=['C','C+','C#','C#+','D','D+','D#','D#+','E','E+','F','F+','F#','F#+','G','G+','G#','G#+','A','A+','A#','A#+','B','B+']
nm24=lambda p: N[int(round(2*p))%24]+str(int(round(2*p))//24-1)
B='/ruta/de/trabajo/h3/base/references/'
def refmod(name):
    spec=importlib.util.spec_from_file_location(name,B+name+'.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
MODS={'sarniezz':'sarniezz_partitura','fabienk':'fabienk_partitura','mata_zyklek':'mata_zyklek_loops'}
for song,target,plen in (('sarniezz','F#4',48),('sarniezz','A+3',48),('fabienk','D#4',None)):
    J,cyc,hi,lo,al=load(song); R=refmod(MODS[song])
    tl=R.timeline()                      # (inicio en corcheas, corcheas, seg/corchea, medible, nombre)
    # tiempo de partitura (s) de cada sección
    t_sec=[]; acc=0.0
    for st,n,e,kn,name in tl: t_sec.append((acc,e,st,name)); acc+=n*e
    inv={}
    for t,d,p,part in al.ref['notes']: inv[(round(float(al.t(t)),6),p,part)]=t
    gu=M.mapped(al,al.ref['guitars']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]; known=M.in_known(his,al)
    hitj={j for _,j in M.match(lead,known,M.exact)}; dt=np.array([d[0] for d in known])
    c=Counter(); tot=Counter()
    for n in lead:
        if nm24(n['p'])!=target: continue
        t=inv[(round(n['t'],6),n['p'],n['part'])]
        k=max(i for i,(a,e,st,name) in enumerate(t_sec) if a<=t+1e-6); a,e,st,name=t_sec[k]
        o=round((t-a)/e,2); pos=o%plen if plen else o
        lo_,hi_=np.searchsorted(dt,n['t']-M.TOL),np.searchsorted(dt,n['t']+M.TOL)
        q=[known[j] for j in range(lo_,hi_) if j not in hitj and abs(abs(known[j][2]-n['p'])-0.5)<0.13]
        tot[(name[:30],n['part'],pos)]+=1
        if q: c[(name[:30],n['part'],pos)]+=1
    print('==',song,target)
    for kk in sorted(tot): print('    ',kk,'desacuerdos',c[kk],'de',tot[kk])
