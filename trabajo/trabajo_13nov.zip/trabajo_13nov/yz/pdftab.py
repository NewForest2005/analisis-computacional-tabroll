"""Lee la tablatura de los PDF de Guitar Pro (solo como referencia de evaluación): compases, cuerdas, trastes, ligaduras
y las marcas de bend (¼, ½, ¾, full). El ritmo no se lee aquí: sale de los WAV de la misma partitura."""
import re, glob
from collections import defaultdict
import pdfplumber

A = '/mnt/user-data/attachments/25e8e225-51e0-5046-8264-de6118f3e1fc/'
TUNING = {6: [64, 59, 55, 50, 45, 40], 4: [43, 38, 33, 28], 5: [43, 38, 33, 28, 23]}   # cuerda 1 (aguda) a la grave, altura real
BEND = {'¼': 0.5, '½': 1.0, '¾': 1.5, 'full': 2.0, '¾¾': 1.5}


def _font(c):
    return c['fontname'].split('+')[-1], round(c['size'], 1)


def _tokens(chars, gap=1.2):
    """Junta caracteres seguidos de la misma línea en palabras: '(', '4', ')' -> '(4)'."""
    out = []
    for c in sorted(chars, key=lambda c: (round(c['top'], 1), c['x0'])):
        if (out and abs(out[-1]['top'] - c['top']) < 0.3 and c['x0'] - out[-1]['x1'] < gap and _font(c) == out[-1]['font']
                and c['text'] != '(' and not (c['text'] == '<' and not out[-1]['text'].endswith('('))
                and not out[-1]['text'].endswith(')') and not (out[-1]['text'].endswith('>') and c['text'] != ')')):
            o = out[-1]; o['text'] += c['text']; o['x1'] = c['x1']; o['bottom'] = max(o['bottom'], c['bottom'])
        else:
            out.append(dict(text=c['text'], x0=c['x0'], x1=c['x1'], top=c['top'], bottom=c['bottom'], font=_font(c)))
    return out


def staves(page):
    """Pentagramas de tablatura: grupos de 4 a 7 líneas horizontales largas con separación de ~5.9 pt."""
    ys = defaultdict(float)
    for l in page.lines:
        if abs(l['top'] - l['bottom']) < 0.5:
            ys[round(l['top'], 1)] += l['x1'] - l['x0']
    for r in page.rects:
        if r['height'] < 0.8 and r['width'] > 20:
            ys[round(r['top'], 1)] += r['width']
    ys = sorted(y for y, L in ys.items() if L > 150)
    groups, cur = [], []
    for y in ys:
        if cur and 5.3 < y - cur[-1] < 6.5:
            cur.append(y)
        else:
            if len(cur) >= 4: groups.append(cur)
            cur = [y]
    if len(cur) >= 4: groups.append(cur)
    return groups


def parse(pdf_path):
    """Lista de compases: dict(num, page, seccion, x0, x1, notas=[dict(x, cuerda, traste, ligada, bend, gracia)])."""
    bars = []
    with pdfplumber.open(pdf_path) as pdf:
        for pi, page in enumerate(pdf.pages):
            toks = _tokens(page.chars)
            for lines in staves(page):
                top, bot = lines[0], lines[-1]
                n = len(lines)
                # barras: rectángulos finos que cubren el pentagrama de tablatura
                bl = sorted({round(r['x0'], 1) for r in page.rects
                             if r['width'] < 1.0 and abs(r['top'] - top) < 1.0 and abs(r['height'] - (bot - top)) < 1.5})
                xs = [l['x0'] for l in page.lines if abs(l['x0'] - l['x1']) < 0.5 and l['top'] <= top + 0.5 and l['bottom'] >= bot - 0.5]
                start = min(xs) if xs else 36.7
                edges = [start]
                for b in bl:                                    # las barras dobles cuentan como una
                    if b > edges[-1] + 6: edges.append(b)
                    elif len(edges) > 1: edges[-1] = max(edges[-1], b)
                sys_tok = [t for t in toks if top - 75 < t['top'] < bot + 8]
                # números de compás: Times 6.4, entre el pentagrama normal y la tablatura de arriba
                nums = [t for t in sys_tok if t['font'] == ('TimesNewRomanPSMT', 6.4) and t['text'].isdigit() and t['top'] < top - 25]
                secs = [t for t in sys_tok if t['font'][0].endswith('BoldMT') and t['font'][1] == 9.2 and t['top'] < top - 25
                        and t['text'] not in ('=',) and not t['text'].isdigit()]
                tempo = [t for t in sys_tok if t['font'][0].endswith('BoldMT') and t['text'].isdigit() and t['top'] < top - 25]
                rest = [t for t in sys_tok if t['font'][0] == 'GPBravura']
                for a, b in zip(edges[:-1], edges[1:]):
                    lab = [t for t in nums if a - 4 <= t['x0'] < min(b - 4, a + 46)]
                    sec = [t for t in secs if a - 12 <= t['x0'] < b - 12]
                    notes = []
                    for t in sys_tok:
                        cx = (t['x0'] + t['x1']) / 2
                        if not (a < cx < b): continue
                        cy = (t['top'] + t['bottom']) / 2
                        if t['font'][0] == 'ArialMT' and top - 3 < cy < bot + 3:
                            k = min(range(n), key=lambda i: abs(lines[i] - cy))
                            m = re.fullmatch(r'(\()?(<)?(\d+|X)(>)?(\))?', t['text'])
                            if not m:
                                notes.append(dict(x=t['x0'], cuerda=k, traste=None, raro=t['text'])); continue
                            lig, arm, fr = bool(m.group(1)), bool(m.group(2)), m.group(3)
                            if fr == 'X':                         # nota muerta: ataque sin altura
                                notes.append(dict(x=t['x0'] + (2.4 if lig else 0), cuerda=k, traste=None, raro='X', ligada=lig,
                                                  gracia=t['font'][1] < 7.0, muerta=True)); continue
                            fr = int(fr)
                            alt = TUNING[n][k] + ({12: 12, 7: 19, 5: 24, 4: 28}.get(fr, fr) if arm else fr)   # armónicos naturales
                            notes.append(dict(x=t['x0'] + (2.4 if lig else 0), cuerda=k, traste=fr, armonico=arm,
                                              ligada=lig, gracia=t['font'][1] < 7.0, bend=0.0, altura=alt))
                    marcas = [t for t in sys_tok if t['font'][1] == 6.4 and t['text'] in BEND and a < t['x0'] < b + 2 and t['top'] < top]
                    for mk in marcas:
                        cand = [nt for nt in notes if nt.get('traste') is not None and nt['x'] <= mk['x0'] + 2.0]
                        if cand:
                            max(cand, key=lambda nt: nt['x'])['bend'] = BEND[mk['text']]
                    otros = [t['text'] for t in sys_tok if a < t['x0'] < b and t['font'][1] in (6.4, 7.4, 8.3)
                             and t['font'][0] != 'ArialMT' and t['text'] not in BEND and not t['text'].isdigit()
                             and top - 40 < t['top'] < bot + 8]
                    mr = [t for t in rest if a < t['x0'] < b]
                    multi = int(''.join(str(ord(ch) - 0xE080) for ch in mr[0]['text'])) if mr and all(0xE080 <= ord(ch) <= 0xE089 for ch in mr[0]['text']) else 1
                    tp = [int(t['text']) for t in tempo if a - 60 <= t['x0'] < b - 60]
                    bars.append(dict(num=int(lab[0]['text']) if lab else None, compases=multi, tempo=tp[0] if tp else None, page=pi + 1, seccion=' '.join(s['text'] for s in sec) or None,
                                     x0=a, x1=b, cuerdas=n, notas=sorted(notes, key=lambda nt: (nt['x'], nt['cuerda'])), otros=otros))
    # compases sin número (silencios de varios compases): se numeran por continuidad
    for i, b in enumerate(bars):
        if b['num'] is None and i > 0 and bars[i - 1]['num'] is not None:
            b['num'] = bars[i - 1]['num'] + bars[i - 1]['compases']
    return bars


def pdf_de(parte):
    return glob.glob(A + f'*Yor_Zarad_{parte}.pdf')[0]


if __name__ == '__main__':
    import sys
    bars = parse(pdf_de(sys.argv[1] if len(sys.argv) > 1 else 'Guitar_I'))
    for b in bars[:14]:
        print(b['num'], b['page'], b['seccion'], round(b['x0']), round(b['x1']), b['cuerdas'], b['otros'],
              ' '.join(('(' if n.get('ligada') else '') + f"{n.get('traste')}" + (')' if n.get('ligada') else '') + f"s{n['cuerda']+1}"
                       + (f"^{n['bend']}" if n.get('bend') else '') + ('g' if n.get('gracia') else '') for n in b['notas']))
    print(len(bars), 'compases; números', bars[0]['num'], '...', bars[-1]['num'])
