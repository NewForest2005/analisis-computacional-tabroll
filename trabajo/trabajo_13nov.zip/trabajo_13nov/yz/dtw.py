"""Alineación partitura → audio oficial de Yor Zarad: DTW entre el render de la partitura (guitarras y bajo, del WAV de
Guitar Pro) y las pistas de guitarra y bajo separadas por Demucs (semilla 0). Croma de cuartos de tono (24 clases) de
guitarra y de bajo, juntas."""
import json, numpy as np
from numpy.lib.stride_tricks import sliding_window_view

SR = 22050; NFFT = 4096; HOP = 1536; DT = HOP / SR


def croma24(x, fmin=55.0, fmax=2500.0):
    fr = sliding_window_view(x, NFFT)[::HOP] * np.hanning(NFFT).astype(np.float32)
    out = []
    f = np.fft.rfftfreq(NFFT, 1 / SR); band = (f >= fmin) & (f <= fmax)
    m = 69 + 12 * np.log2(f[band] / 440); c = np.round(2 * m).astype(int) % 24
    for s in range(0, len(fr), 2000):
        X = np.abs(np.fft.rfft(fr[s:s + 2000], axis=1))[:, band]
        X = np.log1p(100 * X / (X.max() + 1e-9))
        C = np.zeros((len(X), 24))
        for k in range(24):
            C[:, k] = X[:, c == k].sum(axis=1)
        out.append(C)
    C = np.vstack(out)
    return C / (np.linalg.norm(C, axis=1, keepdims=True) + 1e-9)


def leer44(path):
    x = np.fromfile(path, np.float32)
    return x[::2] * 0.5 + x[1::2] * 0.5          # 44.1 kHz -> 22.05 kHz (los dos son renders limpios)


def desfase_global(Cs, Ca, rango=(-5, 20)):
    """Desfase constante audio - partitura que mejor explica toda la canción (solo para acotar el camino)."""
    offs = np.arange(rango[0], rango[1], DT); i = np.arange(len(Cs)); best = []
    for o in offs:
        j = np.round(i + o / DT).astype(int); k = (j >= 0) & (j < len(Ca))
        best.append(np.mean(1 - np.sum(Cs[i[k]] * Ca[j[k]], axis=1)) if k.sum() > len(Cs) // 2 else 9)
    return float(offs[int(np.argmin(best))])


def dtw(Cs, Ca, ventana=12.0, banda=None):
    """Camino monótono: pasos (1,1), (2,1), (1,2) y saltos (k,1) / (1,k) hasta 6 con costo extra (partitura sin audio o
    audio sin partitura). El comienzo y el final pueden caer dentro de los primeros / últimos `ventana` segundos."""
    N, M = len(Cs), len(Ca)
    cost = 1 - Cs @ Ca.T                                         # coseno
    if banda is not None:                                        # (desfase, ancho): fuera de la banda no se puede pasar
        off, ancho = banda
        ii, jj = np.meshgrid(np.arange(N), np.arange(M), indexing='ij')
        cost[np.abs((jj - ii) * DT - off) > ancho] = 50.0
    steps = [((1, 1), 1.0), ((2, 1), 2.4), ((1, 2), 2.4)] + [((k, 1), 2.6 + 0.3 * (k - 2)) for k in range(3, 7)] \
        + [((1, k), 2.6 + 0.3 * (k - 2)) for k in range(3, 7)]
    steps = [((di, dj), w * (di + dj) / 2) for (di, dj), w in steps]   # costo por avance: un paso largo no sale más barato
    W = int(ventana / DT)
    D = np.full((N, M), np.inf); P = np.zeros((N, M), np.int8)
    D[0, :W] = cost[0, :W] + 0.3 * np.arange(W) / W * 0
    for i in range(1, N):
        best = np.full(M, np.inf); arg = np.zeros(M, np.int8)
        if i < W:
            best[:W] = cost[i, :W] + 0.3 * i; arg[:W] = -1    # empezar aquí: la partitura puede empezar después del audio
            best[W:] = np.inf
        for s, ((di, dj), w) in enumerate(steps):
            if i - di < 0: continue
            cand = np.full(M, np.inf)
            cand[dj:] = D[i - di, :M - dj] + w * cost[i, dj:]
            better = cand < best; best[better] = cand[better]; arg[better] = s
        D[i] = best; P[i] = arg
    # final: la mejor celda dentro de la ventana final (partitura o audio)
    cands = [(D[N - 1, j], N - 1, j) for j in range(M - W, M)] + [(D[i, M - 1], i, M - 1) for i in range(N - W, N)]
    _, i, j = min(cands)
    path = [(i, j)]
    while True:
        s = P[i, j]
        if s == -1 or i == 0: break
        (di, dj), _ = steps[s]
        i, j = i - di, j - dj
        path.append((i, j))
    return path[::-1], cost


if __name__ == '__main__':
    # guitarras y bajo juntos: Demucs manda a veces la guitarra grave a la pista del bajo
    r = sum(leer44(f'{p}.f32') for p in ('Guitar_I', 'Guitar_II', 'Guitar_III', 'Bass'))
    a = np.fromfile('real_guitar.f32', np.float32) + np.fromfile('real_bass.f32', np.float32)
    Cs, Ca = croma24(r), croma24(a)
    off = desfase_global(Cs, Ca)
    print('cuadros partitura', len(Cs), 'audio', len(Ca), 'desfase global %.2f s' % off)
    path, cost = dtw(Cs, Ca, banda=(off, 2.5))
    ps = np.array([p[0] for p in path]); pa = np.array([p[1] for p in path])
    borr = np.zeros(len(Cs), bool)
    for (i0, j0), (i1, j1) in zip(path[:-1], path[1:]):
        if i1 - i0 > j1 - j0:
            borr[i0 + 1:i0 + 1 + (i1 - i0) - (j1 - j0)] = True
    borr[:ps[0]] = True; borr[ps[-1] + 1:] = True
    c = np.array([cost[i, j] for i, j in path])
    print('pares', len(path), 'inicio', ps[0] * DT, pa[0] * DT, 'fin', ps[-1] * DT, pa[-1] * DT, 'borrados', borr.sum(),
          'costo medio %.3f' % c.mean())
    J = dict(cancion='yor_zarad', dt=DT, partitura_s=[round(float(i * DT), 4) for i in ps], audio_s=[round(float(j * DT), 4) for j in pa],
             borrado=''.join('1' if b else '0' for b in borr),
             nota=('Camino DTW entre el render de la partitura (WAV de Guitar Pro: guitarras y bajo sumados) y la suma de las '
                   'pistas de guitarra y bajo separadas por Demucs (semilla 0) del audio oficial; croma de cuartos de tono, dentro '
                   'de una banda de 2.5 s alrededor del desfase global. partitura_s y audio_s: pares del mapa monótono; borrado: '
                   'un carácter por cada dt de partitura que el audio no tiene.'))
    json.dump(J, open('yor_zarad.json', 'w'), ensure_ascii=False)
    np.save('dtw_cost_path.npy', c)
