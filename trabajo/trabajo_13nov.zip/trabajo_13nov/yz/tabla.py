"""Tabla final de Yor Zarad: une los ligados sin cambio de altura con su nota y corrige los primeros tiempos sin ataque
medido. Escribe yor_zarad_notas.csv."""
import pickle, csv, numpy as np, collections
F = pickle.load(open('notas_ref.pkl', 'rb')); G = pickle.load(open('inicios.pkl', 'rb')); W = pickle.load(open('wav_feats.pkl', 'rb'))
INI = G['inicios']; S = 60 / 107 / 4
PN = {'Guitar_I': 'G1', 'Guitar_II': 'G2', 'Guitar_III': 'G3', 'Bass': 'B'}


def sube_energia(parte, k, ancho=1.0):
    """¿Empieza a sonar algo en la pista cerca de la semicorchea k? (para ataques suaves que el detector no marca)"""
    t, r = W[parte]['t'], W[parte]['rms']
    a = np.searchsorted(t, (k - ancho) * S); b = np.searchsorted(t, (k + ancho) * S)
    if b <= a + 1: return False
    antes = r[max(0, a - 8):a].mean() if a > 0 else 0.0
    return r[a:b].max() > 4 * antes + 1e-4


def construir():
    out = []
    for parte in PN:
        Fp = sorted([dict(f) for f in F if f['parte'] == parte and not f['gracia']], key=lambda f: (f['k'], f['cuerda']))
        porc = collections.defaultdict(list)
        for f in Fp: porc[f['compas']].append(f)
        for b, fs in porc.items():
            k0 = INI[b - 1]; kmin = min(f['k'] for f in fs)
            for f in fs:
                if f['medido']: continue
                primero = abs(f['k'] - kmin) < 1e-6
                if primero and f['k'] - k0 < 2.0 and (f['ligada'] or sube_energia(parte, k0)):
                    f['k'] = float(k0)                      # ligado o ataque suave en el primer tiempo
                else:
                    f['k'] = round(f['k'] * 2) / 2          # lo interpolado, a la fusa más cercana
        # ligados: sin cambio de altura se suman a su nota; con bend quedan como nota aparte (ligada=1)
        ultimo = {}
        keep = []
        for f in sorted(Fp, key=lambda f: (f['k'], f['cuerda'])):
            c = f['cuerda']
            if f['ligada'] and c in ultimo and abs(ultimo[c]['altura'] - f['altura']) < 0.01:
                u = ultimo[c]; u['dur'] = max(u['dur'], f['k'] + f['dur'] - u['k']); continue
            keep.append(f); ultimo[c] = f
        out += keep
    return out


if __name__ == '__main__':
    T = construir()
    rows = [dict(parte=PN[f['parte']], compas=f['compas'], semicorchea=f['k'], duracion=round(f['dur'], 2), altura=f['altura'] + 12,
                 cuerda=f['cuerda'], traste=f['traste'], bend=f['bend'], ligada=int(f['ligada']), armonico=int(f['armonico']),
                 ataque_medido=int(f['medido'])) for f in T]
    rows.sort(key=lambda r: (r['semicorchea'], r['parte'], -r['altura']))
    with open('yor_zarad_notas.csv', 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader()
        for r in rows: w.writerow({k: (f'{v:g}' if isinstance(v, float) else v) for k, v in r.items()})
    c = collections.Counter(r['parte'] for r in rows)
    print(len(rows), 'notas', dict(c), '| ligadas con bend:', sum(r['ligada'] for r in rows),
          '| ataque medido en el WAV:', sum(r['ataque_medido'] for r in rows))
