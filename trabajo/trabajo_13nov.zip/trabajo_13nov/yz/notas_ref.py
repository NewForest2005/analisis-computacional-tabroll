"""Tabla de notas de Yor Zarad: altura y compás del PDF, ataque en semicorcheas del WAV de la misma partitura.
Por compás: se emparejan los ataques del PDF (en orden de x) con los del WAV que caen dentro del compás; lo que no tiene
ataque en el WAV (ligados de mano izquierda, notas repetidas que el detector no separa) se interpola por x."""
import pickle, numpy as np
import alinear_wav as AW

S = AW.S
P = pickle.load(open('pdf_bars.pkl', 'rb'))
W = pickle.load(open('wav_feats.pkl', 'rb'))
G = pickle.load(open('inicios.pkl', 'rb'))
INI = G['inicios']                               # INI[b-1] = inicio del compás b, en semicorcheas


def x_inicio(bars):
    """x del primer tiempo por compás: el borde más el margen típico (primer compás del sistema o no)."""
    sf = [i == 0 or bars[i]['x0'] < bars[i - 1]['x0'] for i in range(len(bars))]
    d = {True: [], False: []}
    for i, b in enumerate(bars):
        if b['notas']:
            d[sf[i]].append(min(n['x'] for n in b['notas']) - b['x0'])
    ref = {k: float(np.percentile(v, 5)) if v else 8.0 for k, v in d.items()}
    return [b['x0'] + ref[sf[i]] for i, b in enumerate(bars)]


def local(ev, on, med, k0, L, xa, xb):
    """Empareja eventos de un compás con ataques del WAV dentro del compás. Devuelve k (semicorchea) por evento."""
    sel = np.where((on >= (k0 - 0.4) * S) & (on < (k0 + L - 0.4) * S))[0]
    n, m = len(ev), len(sel)
    prior = [k0 + np.clip((e['x'] - xa) / max(xb - xa, 1), 0, 0.999) * L for e in ev]
    C = np.full((n, m), 9.0)
    for i, e in enumerate(ev):
        for j, jj in enumerate(sel):
            kj = on[jj] / S
            if e['muerta'] or not e['alturas']:
                cp = 0.3
            else:
                lo = min(e['base']) - 0.4; hi = max(e['alturas']) + 0.9; mm = med[jj]
                cp = 0.6 if not np.isfinite(mm) else (0.0 if lo <= mm <= hi else min(3.0, 2 * min(abs(mm - lo), abs(mm - hi))))
            C[i, j] = cp + 0.12 * abs(kj - prior[i])
    # DP: saltar un evento cuesta 1.0 (ligado o repetido sin ataque), saltar un ataque 0.8
    D = np.full((n + 1, m + 1), np.inf); D[0, :] = np.arange(m + 1) * 0.8; D[:, 0] = np.arange(n + 1) * 1.0
    B = np.zeros((n + 1, m + 1), int)
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            c = (D[i - 1, j - 1] + C[i - 1, j - 1], D[i - 1, j] + 1.0, D[i, j - 1] + 0.8)
            B[i, j] = int(np.argmin(c)); D[i, j] = c[B[i, j]]
    k = [None] * n; i, j = n, m
    while i > 0 and j > 0:
        if B[i, j] == 0:
            if C[i - 1, j - 1] < 1.5: k[i - 1] = int(round(on[sel[j - 1]] / S))
            i -= 1; j -= 1
        elif B[i, j] == 1: i -= 1
        else: j -= 1
    return k, prior


def interpolar(xs, ks, k0, L, xa, xb):
    """Rellena los k que faltan por x, entre vecinos conocidos (el borde del compás cuenta como vecino)."""
    X = [xa] + [x for x, k in zip(xs, ks) if k is not None] + [xb]
    K = [k0] + [k for k in ks if k is not None] + [k0 + L]
    out = []
    for x, k in zip(xs, ks):
        if k is not None:
            out.append(float(k)); continue
        i = min(max([j for j in range(len(X)) if X[j] <= x], default=0), len(X) - 2)
        f = (x - X[i]) / max(X[i + 1] - X[i], 1e-6)
        out.append(K[i] + f * (K[i + 1] - K[i]))
    return out


def construir():
    filas = []
    for parte in AW.PARTES:
        bars = P[parte]; xi = x_inicio(bars)
        ev, lig = AW.eventos_pdf(bars)
        on = W[parte]['on']; med = AW.altura_ataque(W[parte], on)
        porc = {}
        for e in ev: porc.setdefault(e['bi'], []).append(e)
        ligc = {}
        for l in lig: ligc.setdefault(l['bi'], []).append(l)
        for bi, b in enumerate(bars):
            if b['compases'] > 1 or (bi not in porc and bi not in ligc):
                continue
            k0 = INI[b['num'] - 1]; L = INI[b['num']] - k0
            E = porc.get(bi, [])
            ks, prior = local(E, on, med, k0, L, xi[bi], b['x1']) if E else ([], [])
            # el orden en x tiene que dar ataques crecientes: lo que no, se interpola
            last = -1
            for i, k in enumerate(ks):
                if k is not None and k <= last: ks[i] = None
                elif k is not None: last = k
            todos = sorted([(e['x'], 'ev', e, k) for e, k in zip(E, ks)] + [(l['x'], 'lig', l, None) for l in ligc.get(bi, [])], key=lambda r: r[0])
            kk = interpolar([r[0] for r in todos], [r[3] for r in todos], k0, L, xi[bi], b['x1'])
            for (x, tipo, e, k), kf in zip(todos, kk):
                notas = e['notas'] if tipo == 'ev' else [e['nota']]
                for n in notas:
                    if n.get('altura') is None:
                        continue
                    filas.append(dict(parte=parte, compas=b['num'], k=kf, medido=k is not None, x=x,
                                      altura=n['altura'] + n.get('bend', 0.0), traste=n['traste'], cuerda=n['cuerda'] + 1,
                                      bend=n.get('bend', 0.0), ligada=tipo == 'lig', gracia=bool(n.get('gracia')),
                                      armonico=bool(n.get('armonico'))))
    return filas


def duraciones(filas):
    """Fin de cada nota: el siguiente ataque de la misma pista (o el siguiente ligado), sin pasar de lo que suena en el WAV."""
    out = []
    for parte in AW.PARTES:
        F = sorted([f for f in filas if f['parte'] == parte], key=lambda f: (f['k'], -f['altura']))
        ks = sorted(set(round(f['k'], 3) for f in F))
        F_W = W[parte]; t, rms, c = F_W['t'], F_W['rms'], F_W['conf']
        for f in F:
            nxt = [k for k in ks if k > f['k'] + 1e-6]
            fin = nxt[0] if nxt else f['k'] + 8
            # lo que suena: hasta que el nivel cae 20 dB bajo el del ataque
            a = np.searchsorted(t, f['k'] * S + 0.02); bmax = np.searchsorted(t, fin * S)
            if bmax > a + 1:
                r = rms[a:bmax]; thr = r[:3].max() * 0.1
                low = np.where(r < thr)[0]
                if len(low):
                    fin = min(fin, (t[a + low[0]]) / S)
            f['dur'] = max(0.5, fin - f['k'])
            out.append(f)
    return out


if __name__ == '__main__':
    filas = duraciones(construir())
    import collections
    print(len(filas), 'notas;', collections.Counter(f['parte'] for f in filas))
    print('con ataque medido en el WAV:', sum(f['medido'] for f in filas if not f['ligada']), 'de', sum(1 for f in filas if not f['ligada']))
    frac = [f['k'] % 1 for f in filas if not f['medido']]
    print('interpoladas fuera de la rejilla (>0.2 de semicorchea):', sum(1 for v in frac if 0.2 < v < 0.8), 'de', len(frac))
    pickle.dump(filas, open('notas_ref.pkl', 'wb'))
