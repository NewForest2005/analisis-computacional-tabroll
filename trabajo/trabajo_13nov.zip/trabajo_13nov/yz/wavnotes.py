import numpy as np, pickle, sys
import yin as Y
R={}
for parte in ('Guitar_I','Guitar_II','Guitar_III','Bass','Drums'):
    x=np.fromfile(parte+'.f32',np.float32)
    on,flux=Y.onsets(x)
    if parte!='Drums':
        t,f0,c,r=Y.yin(x,thr=0.45)
        R[parte]=dict(on=on,t=t,f0=f0,conf=c,rms=r)
    else:
        R[parte]=dict(on=on)
    print(parte,len(on),'ataques',file=sys.stderr)
pickle.dump(R,open('wav_feats.pkl','wb'))
