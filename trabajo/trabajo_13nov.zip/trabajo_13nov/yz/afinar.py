"""Afina la alineación con los ataques: por sección, el desfase fino (±150 ms) entre el flujo espectral del render de la
partitura y el de guitarra + bajo reales, alrededor de la recta de la alineación."""
import sys, numpy as np, json
sys.path.insert(0, '../h3/base/src')
import tabroll.evaluation.melodia as M
from numpy.lib.stride_tricks import sliding_window_view
SR = 22050; HOP = 110; N = 1024


def flux(x):
    out = []
    for s in range(0, len(x) - N, HOP * 4000):
        fr = sliding_window_view(x[s:s + HOP * 4000 + N], N)[::HOP] * np.hanning(N)
        Mg = np.log1p(10 * np.abs(np.fft.rfft(fr, axis=1)))
        out.append(Mg)
    Mg = np.vstack(out)
    f = np.maximum(np.diff(Mg, axis=0), 0).sum(1)
    return np.concatenate([[0], f])


def leer44(p):
    x = np.fromfile(p, np.float32); return x[::2] * 0.5 + x[1::2] * 0.5


r = sum(leer44(f'{p}.f32') for p in ('Guitar_I', 'Guitar_II', 'Guitar_III', 'Bass'))
a = np.fromfile('real_guitar.f32', np.float32) + np.fromfile('real_bass.f32', np.float32)
Fr, Fa = flux(r), flux(a)
dtf = HOP / SR
al = M.Alignment('yor_zarad')
res = []
for t0, t1, nm, kn, c in al._pieces:
    if c is None: continue
    i = np.arange(int(t0 / dtf), int(t1 / dtf))
    lags = np.arange(-30, 31)                      # ±150 ms en pasos de 5 ms
    best = []
    for L in lags:
        j = np.round((np.polyval(c, i * dtf)) / dtf).astype(int) + L
        ok = (j >= 0) & (j < len(Fa))
        x, y = Fr[i[ok]], Fa[j[ok]]
        best.append(np.corrcoef(x, y)[0, 1])
    k = int(np.argmax(best)); res.append((t0, t1, nm, lags[k] * dtf, best[k], best[30]))
    print('%7.1f-%7.1f %-48s fino %+4.0f ms  corr %.2f (en 0: %.2f)' % (t0, t1, nm[:48], lags[k] * dtf * 1000, best[k], best[30]))
json.dump([dict(t0=r_[0], t1=r_[1], seccion=r_[2], fino=r_[3], corr=r_[4]) for r_ in res], open('afinado.json', 'w'))
