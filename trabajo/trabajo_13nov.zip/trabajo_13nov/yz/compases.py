"""Inicio de cada compás en semicorcheas del WAV, a partir de los ataques que caen en el primer tiempo."""
import pickle, numpy as np, collections
A=pickle.load(open('alineado.pkl','rb')); P=pickle.load(open('pdf_bars.pkl','rb'))
def inicios(verbose=False):
    votos=collections.defaultdict(list); rango=collections.defaultdict(list)
    for parte in A:
        bars=P[parte]
        sf=[i==0 or bars[i]['x0']<bars[i-1]['x0'] for i in range(len(bars))]
        # x del primer tiempo: la x mínima de las notas en compases sin anacrusa, por tipo (primero del sistema o no)
        dxs={True:[],False:[]}
        for i,b in enumerate(bars):
            if b['notas']: dxs[sf[i]].append(min(n['x'] for n in b['notas'])-b['x0'])
        ref={k:(np.percentile(v,5) if v else None) for k,v in dxs.items()}
        for e in A[parte]['ev']:
            if 'k' not in e or e['c']>=1.0: continue
            b=bars[e['bi']]; rango[e['num']].append(e['k'])
            r=ref[sf[e['bi']]]
            if r is not None and e['x']-b['x0']<=r+2.5 and not e['gracia']:
                votos[e['num']].append((e['k'],parte))
    s={}
    for num,v in votos.items():
        c=collections.Counter(k for k,_ in v); k,n=c.most_common(1)[0]
        s[num]=k
    return s,rango,votos
if __name__=='__main__':
    s,rango,votos=inicios()
    nums=sorted(s)
    print('compases con primer tiempo:',len(nums))
    prev=None; L=collections.Counter()
    for a,b in zip(nums[:-1],nums[1:]):
        d=s[b]-s[a]
        if b-a==1: L[d]+=1
        if b-a==1 and d!=14: print('c.',a,'->',b,'largo',d,'semicorcheas', votos[a][:3])
        if b-a>1 and d!=14*(b-a): print('c.',a,'->',b,f'({b-a} compases)',d,'semicorcheas')
    print(L, 'primer compás con dato', nums[0], s[nums[0]], 'último', nums[-1], s[nums[-1]])

def dp_inicios(nb=201, K=2900, pen=4.0, voto=0.8):
    s0,rango,votos=inicios()
    ks={b:np.array(sorted(v)) for b,v in rango.items()}
    lens=np.arange(4,25); lc=np.where(lens==14,0.0,np.where(np.isin(lens,(12,16)),1.0,np.where(np.isin(lens,(8,10,18)),1.6,2.2)))
    grid=np.arange(K)
    D=np.full(K,np.inf); D[0]=0.0                     # s_1 = 0
    back=[]
    for b in range(1,nb+1):
        k=ks.get(b,np.array([],int))
        lt=np.searchsorted(k,grid,side='left')                 # eventos con k < s_b
        ge=len(k)-np.searchsorted(k,grid,side='left')          # eventos con k >= s_{b+1}
        vb=np.zeros(K)
        for kk,_ in votos.get(b,[]): 
            if kk<K: vb[kk]-=voto
        Ds=D+pen*lt+vb                                         # costo al empezar el compás b en s
        N=np.full(K,np.inf); arg=np.zeros(K,int)
        for L,c in zip(lens,lc):
            cand=np.full(K,np.inf); cand[L:]=Ds[:-L]+c
            better=cand<N; N[better]=cand[better]; arg[better]=L
        N=N+pen*ge                                             # s_{b+1}: los eventos del compás b tienen que quedar antes
        back.append(arg); D=N
    s=[int(np.argmin(D))]
    for b in range(nb,0,-1):
        s.append(s[-1]-back[b-1][s[-1]])
    s=s[::-1]                                                  # s[0]=inicio del c.1 ... s[nb]=final
    return s, ks
if __name__=='__main__':
    s,ks=dp_inicios()
    L=np.diff(s)
    print('largos:',collections.Counter(L.tolist()))
    viol=sum(int(np.sum((ks[b]<s[b-1])|(ks[b]>=s[b]))) for b in ks)
    print('eventos fuera de su compás:',viol,'final',s[-1],'(WAV: %.0f)'%(386.9/AW_S) if False else '')
    cur=None
    for b in range(1,202):
        if L[b-1]!=14: print('c.%d: %d semicorcheas'%(b,L[b-1]), 'eventos',len(ks.get(b,[])))
    pickle.dump(s,open('inicios.pkl','wb'))

def dp_metrica(nb=201, K=2900, pen=3.0, voto=0.5, cambio=4.0, lens=(8,10,12,14,16,18), costo_L={14:0.0,12:0.5,16:0.5,8:0.8,10:1.5,18:1.5}):
    """Como dp_inicios, pero el largo de compás solo cambia donde hace falta (cambio de métrica con costo)."""
    _,rango,votos=inicios()
    ks={b:np.array(sorted(v)) for b,v in rango.items()}
    grid=np.arange(K); nL=len(lens)
    D=np.full((nL,K),np.inf)
    for i,L in enumerate(lens): D[i,0]=costo_L[L]                 # s_1 = 0, con cualquier métrica inicial
    back=[]
    for b in range(1,nb+1):
        k=ks.get(b,np.array([],int))
        lt=np.searchsorted(k,grid,side='left'); ge=len(k)-np.searchsorted(k,grid,side='left')
        vb=np.zeros(K)
        for kk,_ in votos.get(b,[]):
            if kk<K: vb[kk]-=voto
        # elegir la métrica del compás b: la misma que el anterior (gratis) o cambiar
        best=D.min(axis=0); bi=D.argmin(axis=0)
        Dm=np.empty_like(D); src=np.empty((nL,K),int)
        for i,L in enumerate(lens):
            stay=D[i]; ch=best+cambio+costo_L[L]
            Dm[i]=np.minimum(stay,ch); src[i]=np.where(stay<=ch,i,bi)
        N=np.full((nL,K),np.inf); 
        for i,L in enumerate(lens):
            Ds=Dm[i]+pen*lt+vb
            N[i,L:]=Ds[:-L]
            N[i]+=pen*ge
        back.append(src); D=N
    i,sK=np.unravel_index(np.argmin(D),D.shape)
    s=[int(sK)]; Ls=[]
    for b in range(nb,0,-1):
        L=lens[i]; Ls.append(L); s.append(s[-1]-L)
        i=back[b-1][i][s[-1]]
    return s[::-1], Ls[::-1], ks
if __name__=='__main__':
    s,Ls,ks=dp_metrica()
    viol=sum(int(np.sum((ks[b]<s[b-1])|(ks[b]>=s[b]))) for b in ks)
    print('\nmétrica: eventos fuera de su compás',viol,'final',s[-1])
    cur=None
    for b,L in enumerate(Ls,1):
        if L!=cur: print('desde c.%d: %d semicorcheas'%(b,L)); cur=L
    pickle.dump(s,open('inicios.pkl','wb'))
