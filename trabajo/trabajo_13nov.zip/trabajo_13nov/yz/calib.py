import sys, numpy as np
import yin as Y
sys.path.insert(0,'/tmp/claude-0/-home-claude/25e8e225-51e0-5046-8264-de6118f3e1fc/scratchpad/h3/base/src')
from tabroll.reference.guitarpro import parse_gp
gp=parse_gp('/tmp/claude-0/-home-claude/25e8e225-51e0-5046-8264-de6118f3e1fc/scratchpad/h3/base/Angine_de_Poitrine-Yor_Zarad.gp')
Q=60/107
def esperado(track, bar0):
    ev=[e for t in gp['tracks'] if t['name']==track for e in t['events']]
    return sorted(((bar0*3.5+e['onset_beats'])*Q, e['duration_beats']*Q, e['pitch']['midi'], e['pitch']['bend_value']/50, e['pitch']['bend_destination_value']/50) for e in ev)
def medir(x, notes, tails=(0.3,0.6,1.0)):
    t,f0,c,r=Y.yin(x,thr=0.45); m=69+12*np.log2(f0/440); ok=(c>0.5)&np.isfinite(m)
    out=[]
    for a,d,base,b0,b1 in notes:
        sel=np.where((t>=a+0.01)&(t<a+d-0.005)&ok)[0]
        if len(sel)<3: out.append(None); continue
        v=m[sel]; out.append({k:float(np.median(v[int(len(v)*(1-k)):])) for k in tails} | {'ini':float(np.median(v[:max(2,len(v)//4)]))})
    return out
if __name__=='__main__':
    for track,f,bar0 in (('E.Guitar I','Guitar_I.f32',4),):
        x=np.fromfile(f,np.float32)[:int(40*Y.SR)]
        exp=esperado(track,bar0); res=medir(x,exp)
        rows=[]
        for (a,d,base,b0,b1),r in zip(exp,res):
            if r is None: continue
            tgt=base+b1
            rows.append((base,b0,b1,r['ini']-base,r[0.3]-tgt,r[1.0]-tgt))
        rows=np.array(rows)
        for (b0,b1) in sorted(set((r[1],r[2]) for r in rows)):
            g=rows[(rows[:,1]==b0)&(rows[:,2]==b1)]
            for lo,hi in ((0,50),(50,100)):
                gg=g[(g[:,0]>=lo)&(g[:,0]<hi)]
                if len(gg): print(f'bend {b0}->{b1} registro {lo}-{hi}: n={len(gg)} | final (último 30%) − escrito: mediana {np.median(gg[:,4]):+.2f} [{np.min(gg[:,4]):+.2f}, {np.max(gg[:,4]):+.2f}] | ataque − base {np.median(gg[:,3]):+.2f}')
