"""Transcripción de las pistas sintetizadas de la partitura: YIN (una voz) + ataques por flujo espectral. Distinto del cuaderno."""
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
SR=44100
def yin(x, frame=4096, hop=256, fmin=38.0, fmax=1400.0, thr=0.15):
    tmin, tmax = int(SR/fmax), min(int(SR/fmin), frame//2)
    W = frame - tmax
    nfr = 1 + (len(x)-frame)//hop
    f0 = np.full(nfr, np.nan); conf = np.zeros(nfr); rms=np.zeros(nfr)
    for s in range(0, nfr, 2000):
        e = min(nfr, s+2000)
        idx = np.arange(s, e)[:, None]*hop + np.arange(frame)[None, :]
        fr = x[idx].astype(np.float64)
        rms[s:e] = np.sqrt((fr**2).mean(axis=1))
        F = np.fft.rfft(fr, 2*frame, axis=1)
        a = np.fft.irfft(F * np.conj(np.fft.rfft(fr[:, :W], 2*frame, axis=1)), axis=1)[:, :tmax+1]   # sum_j x_j x_{j+tau}, j<W
        c2 = np.cumsum(np.concatenate([np.zeros((e-s,1)), fr**2], axis=1), axis=1)
        E0 = c2[:, W][:, None]
        tau = np.arange(tmax+1)
        Et = c2[:, tau+W] - c2[:, tau]
        d = E0 + Et - 2*a
        d[:, 0] = 0
        cm = np.ones_like(d)
        cs = np.cumsum(d[:, 1:], axis=1)
        cm[:, 1:] = d[:, 1:] * tau[1:] / np.maximum(cs, 1e-12)
        for i in range(e-s):
            c = cm[i]
            below = np.where(c[tmin:tmax] < thr)[0]
            if len(below):
                t = below[0] + tmin
                while t+1 < tmax and c[t+1] < c[t]: t += 1
            else:
                t = int(np.argmin(c[tmin:tmax])) + tmin
            if 1 <= t < tmax:
                y0, y1, y2 = c[t-1], c[t], c[t+1]
                den = y0 - 2*y1 + y2
                dt = 0.5*(y0 - y2)/den if abs(den) > 1e-12 else 0.0
                f0[s+i] = SR/(t + np.clip(dt, -0.5, 0.5)); conf[s+i] = 1 - c[t]
    times = (np.arange(nfr)*hop + frame/2)/SR
    return times, f0, conf, rms

def onsets(x, n=2048, hop=256, k=1.5, gap=0.05):
    win = np.hanning(n).astype(np.float32); nfr = 1 + (len(x)-n)//hop
    flux = np.zeros(nfr); prev = None
    for s in range(0, nfr, 4000):
        e = min(nfr, s+4000); idx = np.arange(s, e)[:, None]*hop + np.arange(n)[None, :]
        L = np.log1p(100*np.abs(np.fft.rfft(x[idx]*win, axis=1)))
        if prev is not None: L = np.vstack([prev, L])
        dL = np.maximum(np.diff(L, axis=0), 0).sum(axis=1)
        flux[s+(0 if prev is None else 0):e] = np.concatenate([[0], dL]) if prev is None else dL
        prev = L[-1:]
    # umbral adaptativo
    from scipy.ndimage import uniform_filter1d, maximum_filter1d
    m = uniform_filter1d(flux, 64); sd = np.sqrt(uniform_filter1d((flux-m)**2, 64))
    pk = (flux == maximum_filter1d(flux, 7)) & (flux > m + k*sd) & (flux > 0.02*flux.max())
    t = (np.where(pk)[0]*hop + n/2)/SR
    out = []
    for v in t:
        if not out or v - out[-1] > gap: out.append(v)
    return np.array(out), flux

def notas(x, rms_min_db=-45, conf_min=0.75, tail=0.6, split=0.4):
    times, f0, conf, rms = yin(x)
    on, _ = onsets(x)
    ref = np.percentile(rms[rms > 0], 99)
    voiced = (conf >= conf_min) & (20*np.log10(rms/ref + 1e-12) > rms_min_db) & np.isfinite(f0)
    midi = np.where(voiced, 69 + 12*np.log2(f0/440.0), np.nan)
    # límites: ataques y saltos de altura sostenidos
    cuts = set(np.searchsorted(times, on))
    m = np.where(np.isfinite(midi), midi, -99)
    for i in range(3, len(m)-3):
        if np.isfinite(midi[i]) and np.isfinite(midi[i-1]):
            if abs(np.nanmedian(midi[i:i+3]) - np.nanmedian(midi[i-3:i])) > split + 0.35 and abs(midi[i]-midi[i-1]) > split:
                cuts.add(i)
    cuts = sorted(c for c in cuts if 0 < c < len(midi))
    edges = [0] + cuts + [len(midi)]
    out = []
    for a, b in zip(edges[:-1], edges[1:]):
        seg = midi[a:b]; ok = np.isfinite(seg)
        if ok.sum() < 4: continue
        idx = np.where(ok)[0]
        # tramo sonoro continuo desde el primer cuadro sonoro
        start = idx[0]; stop = start
        while stop+1 < len(seg) and ok[stop+1]: stop += 1
        v = seg[start:stop+1]
        if len(v) < 4: continue
        k0 = int(len(v)*(1-tail))
        out.append((float(times[a+start]), float(times[a+stop]), float(np.median(v[k0:])), float(np.median(v[:max(2, len(v)//3)]))))
    return out, (times, midi)
