"""Une la tablatura del PDF (alturas, compases) con los WAV de la misma partitura (tiempos): alineación de secuencias por
pista, con la altura medida en el ataque. Todo en tiempo de la partitura: el WAV va a negra = 107 desde t = 0."""
import pickle, numpy as np

S = 60 / 107 / 4                                      # semicorchea
PARTES = ('Guitar_I', 'Guitar_II', 'Guitar_III', 'Bass')


def eventos_pdf(bars):
    """Ataques en orden: los acordes (misma x) son un solo evento. Las ligadas no atacan; se guardan aparte."""
    ev, lig = [], []
    for bi, b in enumerate(bars):
        ns = [n for n in b['notas'] if not n.get('ligada')]
        grupos = []
        for n in ns:
            if grupos and abs(n['x'] - grupos[-1][0]['x']) < 1.5:
                grupos[-1].append(n)
            else:
                grupos.append([n])
        for g in grupos:
            alts = [n['altura'] + n['bend'] for n in g if n.get('altura') is not None]
            base = [n['altura'] for n in g if n.get('altura') is not None]
            ev.append(dict(bi=bi, num=b['num'], x=g[0]['x'], notas=g, alturas=alts, base=base,
                           gracia=all(n.get('gracia') for n in g), muerta=all(n.get('muerta') for n in g)))
        lig += [dict(bi=bi, num=b['num'], x=n['x'], nota=n) for n in b['notas'] if n.get('ligada')]
    return ev, lig


def altura_ataque(F, on, a=0.02, b=0.10):
    t, f0, c = F['t'], F['f0'], F['conf']
    out = np.full(len(on), np.nan)
    i0 = np.searchsorted(t, on + a); i1 = np.searchsorted(t, on + b)
    for k, (x, y) in enumerate(zip(i0, i1)):
        sel = (c[x:y] > 0.5) & np.isfinite(f0[x:y])
        if sel.sum() >= 2:
            out[k] = np.median(69 + 12 * np.log2(f0[x:y][sel] / 440))
    return out


def costo(ev, med):
    """Costo de emparejar cada evento del PDF con cada ataque del WAV (matriz completa, numpy)."""
    N, M = len(ev), len(med)
    C = np.full((N, M), 2.5)
    for i, e in enumerate(ev):
        if e['muerta'] or not e['alturas']:
            C[i] = 0.6                                 # nota muerta: cualquier ataque sirve
            continue
        lo = min(e['base']) - 0.4; hi = max(e['alturas']) + 0.9      # el render suena hasta ~0.5 st alto en el grave
        d = np.where(np.isnan(med), 1.0, np.where(med < lo, lo - med, np.where(med > hi, med - hi, 0.0)))
        C[i] = np.minimum(d * 2.0, 2.5)
        if e['gracia']:
            C[i] += 0.2
    return C


def alinear(C, salto_pdf=1.2, salto_wav=1.0, salto_gracia=0.3, gracia=None):
    N, M = C.shape
    sp = np.full(N, salto_pdf)
    if gracia is not None:
        sp[gracia] = salto_gracia
    D = np.full((N + 1, M + 1), np.inf); D[0] = np.arange(M + 1) * salto_wav
    B = np.zeros((N + 1, M + 1), np.int8)             # 0 diagonal, 1 arriba (salta PDF), 2 izquierda (salta WAV)
    j = np.arange(M + 1)
    for i in range(1, N + 1):
        diag = np.full(M + 1, np.inf); diag[1:] = D[i - 1, :-1] + C[i - 1]
        up = D[i - 1] + sp[i - 1]
        A = np.minimum(diag, up); src = np.where(diag <= up, 0, 1)
        cm = np.minimum.accumulate(A - j * salto_wav)
        row = cm + j * salto_wav
        left = row < A - 1e-12
        D[i] = row; B[i] = np.where(left, 2, src)
    i, jj = N, M; pares = []
    while i > 0 and jj > 0:
        b = B[i, jj]
        if b == 0: pares.append((i - 1, jj - 1)); i -= 1; jj -= 1
        elif b == 1: i -= 1
        else: jj -= 1
    return pares[::-1], D[N, M]


if __name__ == '__main__':
    P = pickle.load(open('pdf_bars.pkl', 'rb'))
    W = pickle.load(open('wav_feats.pkl', 'rb'))
    res = {}
    for parte in PARTES:
        ev, lig = eventos_pdf(P[parte])
        on = W[parte]['on']; med = altura_ataque(W[parte], on)
        C = costo(ev, med)
        pares, tot = alinear(C, gracia=np.array([e['gracia'] for e in ev]))
        ok = [(i, j) for i, j in pares if C[i, j] < 1.0]
        for i, j in pares:
            ev[i]['t'] = float(on[j]); ev[i]['k'] = int(round(on[j] / S)); ev[i]['med'] = float(med[j]); ev[i]['c'] = float(C[i, j])
        res[parte] = dict(ev=ev, lig=lig)
        dif = np.array([ev[i]['med'] - max(ev[i]['alturas']) for i, j in ok if ev[i]['alturas'] and len(ev[i]['notas']) == 1])
        print(parte, 'eventos PDF', len(ev), 'ataques WAV', len(on), 'pareados', len(pares), 'buenos', len(ok),
              'medido - escrito: mediana %+.2f, |dif|>0.5: %d' % (np.nanmedian(dif), np.sum(np.abs(dif) > 0.5)))
    pickle.dump(res, open('alineado.pkl', 'wb'))
