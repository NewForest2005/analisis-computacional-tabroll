"""Afina el camino DTW (cuadros de 70 ms) con los ataques: en ventanas de 8 s de partitura, el desfase (±150 ms, pasos de
5 ms) que mejor alinea el flujo espectral del render con el de guitarra + bajo reales. Se suaviza con la mediana de
tres ventanas y se suma a audio_s."""
import json, numpy as np
from scipy.ndimage import median_filter
import afinar as A          # flux, Fr, Fa (calculados al importar)
J = json.load(open('yor_zarad.json'))
s = np.array(J['partitura_s']); a = np.array(J['audio_s'])
dtf = A.dtf; WIN = 8.0
centros, lags = [], []
for t0 in np.arange(0, s[-1], WIN):
    i = np.arange(int(t0 / dtf), int(min(t0 + WIN, s[-1]) / dtf))
    base = np.interp(i * dtf, s, a)
    cs = []
    for L in range(-30, 31):
        j = np.round(base / dtf).astype(int) + L; ok = (j >= 0) & (j < len(A.Fa))
        cs.append(np.corrcoef(A.Fr[i[ok]], A.Fa[j[ok]])[0, 1] if ok.sum() > 50 else -1)
    k = int(np.argmax(cs)); centros.append(t0 + WIN / 2); lags.append((k - 30) * dtf if cs[k] > 0.15 else np.nan)
lags = np.array(lags); ok = np.isfinite(lags)
lags[~ok] = np.interp(np.array(centros)[~ok], np.array(centros)[ok], lags[ok])
lags = median_filter(lags, 3, mode='nearest')
fino = np.interp(s, centros, lags)
J['audio_s'] = [round(float(x), 4) for x in a + fino]
J['nota'] += (' Afinado con los ataques: en ventanas de 8 s, el desfase de ±150 ms que mejor alinea el flujo espectral del '
              'render con el de las pistas reales, suavizado con la mediana de tres ventanas.')
json.dump(J, open('yor_zarad.json', 'w'), ensure_ascii=False)
print('desfase fino por ventana (ms):', np.round(lags * 1000).astype(int).tolist())
