from comun import *
TOL=M.TOL
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    gu=M.mapped(al,al.ref['guitars']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]
    known=M.in_known(his,al)
    hitj={j for _,j in M.match(lead,known,M.exact)}; hitk={k for k,_ in M.match(lead,known,M.exact)}
    dt=np.array([d[0] for d in known])
    up=Counter(); secs=Counter(); bajo47=0; tot=0
    for k,n in enumerate(lead):
        tot+=1; bajo47+= n['p']<47
        lo_,hi_=np.searchsorted(dt,n['t']-TOL),np.searchsorted(dt,n['t']+TOL)
        cand=[known[j] for j in range(lo_,hi_) if j not in hitj]
        h=[d for d in cand if any(abs(d[2]-n['p']-x)<0.26 for x in (12,19,7,24))]
        if h:
            up['ref<47' if n['p']<47 else 'ref>=47']+=1; secs[al.ref['sections'][n['sec']][2][:45]]+=1
    print(song,'| notas de la melodía bajo MIDI 47 (piso de la voz aguda):',bajo47,'de',tot,'| errores hacia arriba (+7,+12,+19,+24):',dict(up))
    print('   secciones:',secs.most_common(4))
