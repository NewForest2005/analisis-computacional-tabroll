from bajo import *
TOL=M.TOL
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    ba=M.mapped(al,al.ref['basses']); low=M.top_line(ba,low=True)
    for h in (0.6,0.3):
        raw,on=notas_bajo(song,h)
        sb=M.calib(low,raw); los=M.in_known([(a-sb,b-sb,p) for a,b,p in raw],al)
        hit=M.match(low,los,M.exact); hk={k for k,_ in hit}
        dt=np.array([d[0] for d in los]); ons=np.array(on)-sb
        d_on=[]; dur=[]
        for k,n in enumerate(low):
            if k in hk: continue
            lo_,hi_=np.searchsorted(dt,n['t']-TOL),np.searchsorted(dt,n['t']+TOL)
            if hi_>lo_: continue
            sus=[d for d in los if d[0]<n['t']-TOL and d[1]>n['t'] and M.exact(d[2],n['p'])]
            if not sus: continue
            j=np.searchsorted(ons,n['t']); cand=[abs(ons[x]-n['t']) for x in (j-1,j) if 0<=x<len(ons)]
            d_on.append(min(cand) if cand else 9); dur.append(n['te']-n['t'])
        d_on=np.array(d_on)
        print(song,'umbral',h,'| re-ataques perdidos:',len(d_on),'| con ataque detectado a <75 ms:',int((d_on<0.075).sum()),
              '| duración típica de esas notas (s):',round(float(np.median(dur)),3) if dur else None)
