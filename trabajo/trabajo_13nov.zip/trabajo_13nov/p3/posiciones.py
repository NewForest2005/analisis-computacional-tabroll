from comun import *
from collections import Counter
import importlib
N=['C','C+','C#','C#+','D','D+','D#','D#+','E','E+','F','F+','F#','F#+','G','G+','G#','G#+','A','A+','A#','A#+','B','B+']
nm24=lambda p: N[int(round(2*p))%24]+str(int(round(2*p))//24-1)
for song,target in (('sarniezz','F#4'),('sarniezz','A+3'),('sarniezz','C#+4'),('fabienk','D#4'),('mata_zyklek','F3'),('mata_zyklek','D3')):
    J,cyc,hi,lo,al=load(song)
    gu=M.mapped(al,al.ref['guitars']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]; known=M.in_known(his,al)
    hitk={k for k,_ in M.match(lead,known,M.exact)}; hitj={j for _,j in M.match(lead,known,M.exact)}
    dt=np.array([d[0] for d in known])
    if 'o' not in lead[0] and 'onset' not in lead[0]: print('claves',list(lead[0].keys())); 
    starts={}
    secs=al.ref['sections']
    c=Counter(); tot=Counter()
    for k,n in enumerate(lead):
        if nm24(n['p'])!=target: continue
        name=secs[n['sec']][2]
        pos=n.get('o', n.get('onset'))
        key=(name[:42], n.get('part'), round(pos-secs[n['sec']][0],2) if pos is not None else None)
        lo_,hi_=np.searchsorted(dt,n['t']-M.TOL),np.searchsorted(dt,n['t']+M.TOL)
        q=[known[j] for j in range(lo_,hi_) if j not in hitj and abs(abs(known[j][2]-n['p'])-0.5)<0.13]
        tot[(name[:42],n.get('part'))]+=1
        if q: c[(name[:42],n.get('part'))]+=1
    print('==',song,target,'| desacuerdos de ¼ por sección y parte (de cuántas apariciones):')
    for kk,v in c.most_common(): print('    ',kk,v,'de',tot[kk])
