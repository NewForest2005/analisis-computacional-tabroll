from linea import *
from scipy.ndimage import median_filter as mf
def notas_reg(song, sd=12.0, win_s=None, floor=47.0, w=0.3):
    b=base(song); J=b['J']; cyc=b['cyc']; Sn=b['Sn']; cand=b['cand']; ish=cand>=floor
    Snote=Sn[ish].max(axis=0); cons=ns['cycle_consensus'](Sn[ish],cyc,SR,HOP)
    bl=ns['viterbi_pitch'](cons,cand[ish],np.percentile(Snote,55))
    c=cand[ish][:,None]
    if win_s is None:
        reg=np.full(bl.shape, float(np.nanmedian(bl)))
    else:
        k=int(win_s*SR/HOP)|1; v=np.where(np.isfinite(bl),bl,np.nan)
        # mediana móvil ignorando huecos: rellena huecos con la mediana global y filtra
        g=float(np.nanmedian(bl)); reg=mf(np.where(np.isfinite(v),v,g),size=k,mode='nearest')
    atr=(1-w)+w*np.exp(-0.5*((c-reg[None,:])/sd)**2)
    mel=ns['viterbi_pitch'](cons*atr,cand[ish],np.percentile(Snote,55))
    gate=ns['guitar_gate'](b['stem'],len(mel),HOP,SR)
    raw=ns['extract_notes'](np.where(gate,mel,np.nan),Snote,np.array(J['onsets_h_s']),SR,HOP,J['off'],50)
    return ns['drop_loose_notes'](raw,cyc)
if __name__=='__main__':
    for song in SONGS:
        J,cyc,hi,lo,al=load(song); res=[]
        for sd,win,w in ((12,None,0.3),(6,None,0.3),(24,None,0.3),(12,None,0.0),(12,10,0.3),(12,20,0.3),(12,40,0.3),(6,20,0.3),(12,20,0.5)):
            e=evaluar(song,notas_reg(song,sd,win,w=w),lo); res.append((f'sd{sd} v{win} w{w}',e['principal'],e['principal_sin_octava']))
        print(song,res)
