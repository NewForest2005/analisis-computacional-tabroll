"""Clips para arbitrar de oído los desacuerdos de cuarto de tono entre la partitura y el cuaderno (a ciegas)."""
import subprocess, random, csv
from comun import *
SR=22050; OUT='/tmp/claude-0/-home-claude/25e8e225-51e0-5046-8264-de6118f3e1fc/scratchpad/arbitraje/'
N=['C','C+','C#','C#+','D','D+','D#','D#+','E','E+','F','F+','F#','F#+','G','G+','G#','G#+','A','A+','A#','A#+','B','B+']
ES={'C':'Do','D':'Re','E':'Mi','F':'Fa','G':'Sol','A':'La','B':'Si'}
def nombre(p):                                         # altura sonora → nombre en español (con ¼ para medio sostenido)
    k=int(round(2*p)); s=N[k%24]; base=ES[s[0]]+('#' if '#' in s else '')+('¼' if '+' in s else '')
    return base
nm24=lambda p: N[int(round(2*p))%24]+str(int(round(2*p))//24-1)
CASOS=[('sarniezz','A+3'),('sarniezz','C#+4'),('sarniezz','F#4'),('mata_zyklek','F3'),('mata_zyklek','D3'),('fabienk','D#4')]
def synth(notes, t0, dur, off):
    y=np.zeros(int(dur*SR),np.float32)
    for t,te,p in notes:
        a,b=int((t-t0)*SR),int((te-t0)*SR)
        if b<=0 or a>=len(y): continue
        a,b=max(a,0),min(b,len(y)); tt=np.arange(b-a)/SR; f=440*2**((p+off-69)/12)
        w=sum(np.sin(2*np.pi*h*f*tt)/h for h in (1,2,3,4)); env=np.minimum(1,tt/0.01)*np.exp(-tt*2.5); y[a:b]+=0.25*w*env
    return y
def mp3(st, path):
    subprocess.run(['ffmpeg','-y','-v','error','-f','f32le','-ar',str(SR),'-ac','2','-i','-','-b:a','160k',path],input=st.astype(np.float32).tobytes(),check=True)
rng=random.Random(20261113)
clave=[]; filas=[]
items=[]
for song,target in CASOS:
    J,cyc,hi,lo,al=load(song)
    gu=M.mapped(al,al.ref['guitars']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]; known=M.in_known(his,al)
    hitj={j for _,j in M.match(lead,known,M.exact)}; dt=np.array([d[0] for d in known])
    occ=[]
    for n in lead:
        if nm24(n['p'])!=target: continue
        lo_,hi_=np.searchsorted(dt,n['t']-M.TOL),np.searchsorted(dt,n['t']+M.TOL)
        q=[known[j] for j in range(lo_,hi_) if j not in hitj and abs(abs(known[j][2]-n['p'])-0.5)<0.13]
        if q: occ.append((n,q[0][2]))
    pick=[occ[i] for i in sorted(set(np.linspace(0,len(occ)-1,3).round().astype(int)))]
    for n,det in pick: items.append(('caso',song,target,n,det,sh,lead,J['off']))
# controles: una nota de cuarto de tono por canción que el cuaderno y la partitura leen igual
for song in ('sarniezz','mata_zyklek','fabienk'):
    J,cyc,hi,lo,al=load(song)
    gu=M.mapped(al,al.ref['guitars']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]; known=M.in_known(his,al)
    hk={k for k,_ in M.match(lead,known,M.exact)}
    ok=[n for k,n in enumerate(lead) if k in hk and round(2*n['p'])%2==1 and n['te']-n['t']>=0.15]
    n=ok[len(ok)//2]; items.append(('control',song,nm24(n['p']),n,n['p'],sh,lead,J['off']))
rng.shuffle(items)
corto={'sarniezz':'sar','mata_zyklek':'mata','fabienk':'fab'}
x_cache={}
for k,(tipo,song,target,n,det,sh,lead,off) in enumerate(items,1):
    if song not in x_cache: x_cache[song]=np.fromfile(f'{song}.gtr.f32',np.float32)
    x=x_cache[song]; T=n['t']+sh; A0=T-2.0; dur=5.0
    L=x[int(A0*SR):int((A0+dur)*SR)]; L=L/(np.abs(L).max()+1e-9)*0.8
    ventana=[(m['t']+sh,m['te']+sh,m['p']) for m in lead if A0-1<=m['t']+sh<A0+dur]
    deltas=[0.0,0.5,-0.5]; rng.shuffle(deltas)
    partes=[]
    for d in deltas:
        notas=[(t,te,p+d if abs(t-T)<1e-6 and abs(p-n['p'])<1e-6 else p) for t,te,p in ventana]
        R=synth(notas,A0,len(L)/SR,off); R=R/(np.abs(R).max()+1e-9)*0.6
        partes.append(np.stack([L,R[:len(L)]],1)); partes.append(np.zeros((int(0.8*SR),2)))
    mm,ss=int(T//60),int(T%60)
    archivo=f'{k:02d}_{corto[song]}_{mm}m{ss:02d}s.mp3'
    mp3(np.concatenate(partes[:-1]),OUT+archivo)
    sec=al_sec=M.Alignment(song).ref['sections'][n['sec']][2] if False else ''
    clave.append(dict(archivo=archivo,tipo=tipo,cancion=song,nota_partitura=target,t_audio=round(T,2),
                      repeticiones=';'.join(f'{d:+.1f}' for d in deltas),
                      cuaderno=f'{det-n["p"]:+.1f}' if tipo=='caso' else '+0.0'))
    filas.append(dict(archivo=archivo,cancion={'sarniezz':'Sarniezz','mata_zyklek':'Mata Zyklek','fabienk':'Fabienk'}[song],
                      minuto=f'{mm}:{ss:02d}',nota_partitura=nombre(n['p']),eleccion='',seguridad='',comentario=''))
    print(archivo,tipo,song,target,f'{T:.2f}',deltas)
with open('/tmp/claude-0/-home-claude/25e8e225-51e0-5046-8264-de6118f3e1fc/scratchpad/p3/clave_arbitraje.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(clave[0])); w.writeheader(); w.writerows(clave)
with open(OUT+'respuestas.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(filas[0])); w.writeheader(); w.writerows(filas)
