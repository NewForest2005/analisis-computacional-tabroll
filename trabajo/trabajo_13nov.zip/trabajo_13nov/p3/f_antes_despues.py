from comun import *
from pathlib import Path
import tabroll.evaluation.melodia as MM
orig=MM.REFS
res={}
for tag,d in (('antes',orig),('conservador',Path('refs_cons').resolve()),('regla literal',Path('refs_lit').resolve())):
    MM.REFS=Path(d)
    for song in ('sarniezz','fabienk'):
        J=json.load(open(glob.glob(R+SONGS[song]+'/line_diagnostics.json')[0]))
        r=MM.evaluate(song, MM._notes(J['raw_high']), MM._notes(J['raw_bass']))
        res[(tag,song)]=(round(r['principal'],1),round(r['principal_sin_octava'],1),round(r['mas_aguda'],1),r['notas_principal'])
MM.REFS=orig
for k,v in res.items(): print(k,v)
