import time, numpy as np
from linea import *
C2='/tmp/claude-0/-home-claude/25e8e225-51e0-5046-8264-de6118f3e1fc/scratchpad/h3/base/src/tabroll/cells/stereo_salience.py'
nuevo=dict(ns); exec(open(C2).read(), nuevo)
for song in ('mata_zyklek',):
    b=base(song); S,M,st,cand=b['S'],b['M'],b['st'],b['cand']
    t=time.time(); a1=ns['stereo_salience'](S,M,st,cand,SR,NF,HOP,True); a2=ns['stereo_salience'](S,M,st,cand,SR,NF,HOP,True,gamma=0.0); t_old=time.time()-t
    t=time.time(); c={}; b1=nuevo['stereo_salience'](S,M,st,cand,SR,NF,HOP,True,cache=c); b2=nuevo['stereo_salience'](S,M,st,cand,SR,NF,HOP,True,gamma=0.0,cache=c); t_new=time.time()-t
    print(song,'idénticas:',np.array_equal(a1,b1),np.array_equal(a2,b2),f'| antes {t_old:.1f} s, ahora {t_new:.1f} s')
