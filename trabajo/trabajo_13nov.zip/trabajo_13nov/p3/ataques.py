from linea import *
for f in ('mel_bank','onset_envelopes','detect_onsets'):
    exec(open(C+f+'.py').read(), ns)
def onsets_gtr(song, height=0.3, win=0.3):
    b=base(song); fps=SR/256
    return ns['detect_onsets'](ns['onset_envelopes'](b['stem'],SR)[0],fps,height=height,win=win)
if __name__=='__main__':
    for song in SONGS:
        J,cyc,hi,lo,al=load(song); b=base(song)
        raw0,mel=notas_agudas(song)
        Sn=b['Sn']; ish=b['cand']>=47; Snote=Sn[ish].max(axis=0)
        gate=ns['guitar_gate'](b['stem'],len(mel),HOP,SR)
        on_st=np.array(J['onsets_h_s']); on_rep=onsets_gtr(song)
        res=[('guardados',len(on_st),evaluar(song,raw0,lo)['principal'])]
        for h in (0.3,0.25,0.2,0.15,0.1):
            on=onsets_gtr(song,h)
            raw=ns['drop_loose_notes'](ns['extract_notes'](np.where(gate,mel,np.nan),Snote,on,SR,HOP,J['off'],50),cyc)
            e=evaluar(song,raw,lo); res.append((h,len(on),e['principal'],e['det']))
        print(song,res)
