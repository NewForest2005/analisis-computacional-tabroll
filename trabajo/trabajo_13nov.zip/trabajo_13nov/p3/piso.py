from linea import *
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    res=[]
    for fl in (47.0,45.0,43.0,40.0):
        raw,_=notas_agudas(song,floor=fl)
        e=evaluar(song,raw,lo); res.append((fl,e['principal'],e['principal_sin_octava'],e['mas_aguda'],e['det']))
    print(song,res)
