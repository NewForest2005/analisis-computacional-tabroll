from comun import *
import time
SR=22050
def stft(x, nfft=4096, hop=512):
    pad=nfft//2; xp=np.pad(x,(pad,pad),mode='reflect').astype(np.float32)
    n=1+(len(xp)-nfft)//hop; win=np.hanning(nfft+1)[:-1].astype(np.float32)
    out=np.empty((nfft//2+1,n),np.float32)
    for s in range(0,n,2000):
        e=min(n,s+2000); idx=np.arange(s,e)[:,None]*hop+np.arange(nfft)[None,:]
        out[:,s:e]=np.abs(np.fft.rfft(xp[idx]*win,axis=1)).T
    return out

def fine_pitch(notes, X, off, nfft=4096, hop=512, H=8, win_c=40.0, skip=1):
    """Altura fina de cada nota: el pico de cada armónico cerca de donde lo pone la nota, con interpolación parabólica."""
    df=SR/nfft; L=np.log(X+1e-9); out=[]
    for a,b,p in notes:
        f0=440*2**((p+off-69)/12)
        fr=np.arange(int(round(a*SR/hop))+skip, max(int(round(b*SR/hop)), int(round(a*SR/hop))+skip+1))
        fr=fr[fr<X.shape[1]]
        ests=[]; ws=[]
        for h in range(1,H+1):
            k=f0*h/df
            w=max(1,int(np.ceil(k*(2**(win_c/1200)-1))))
            k0,k1=int(np.floor(k))-w, int(np.ceil(k))+w+1
            if k1>=X.shape[0]-1 or k0<1: break
            seg=L[k0:k1, fr]                                    # (bins, cuadros)
            j=np.argmax(seg,axis=0)+k0
            ok=(j>k0)&(j<k1-1)
            if not ok.any(): continue
            jj=j[ok]; ff=fr[ok]
            y0,y1,y2=L[jj-1,ff],L[jj,ff],L[jj+1,ff]
            den=(y0-2*y1+y2); d=np.where(np.abs(den)>1e-9,0.5*(y0-y2)/den,0.0)
            fpk=(jj+np.clip(d,-0.5,0.5))*df/h
            ests.append(12*np.log2(fpk/440)+69-off); ws.append(X[jj,ff]*h)
        if not ests: out.append(np.nan); continue
        e=np.concatenate(ests); w=np.concatenate(ws)
        o=np.argsort(e); cw=np.cumsum(w[o]); out.append(float(e[o][np.searchsorted(cw,cw[-1]/2)]))   # mediana ponderada
    return np.array(out)

def corrige(notes, fine, margin=0.1):
    new=[]
    for (a,b,p),f in zip(notes,fine):
        if np.isfinite(f):
            q=p+0.5*np.sign(f-p) if abs(f-p)>0.25+margin and abs(f-p)<0.75 else p
        else: q=p
        new.append((a,b,float(q)))
    return new

if __name__=='__main__':
    for song in SONGS:
        J,cyc,hi,lo,al=load(song)
        x=np.fromfile(f'{song}.gtr.f32',np.float32); X=stft(x)
        t=time.time(); fine=fine_pitch(hi,X,J['off']); dt_=time.time()-t
        base=evaluar(song,hi,lo)
        res={}
        for m in (0.0,0.05,0.1,0.15):
            new=corrige(hi,fine,m); ch=sum(1 for u,v in zip(hi,new) if u[2]!=v[2])
            res[m]=(evaluar(song,new,lo)['principal'], ch)
        dev=np.abs(fine-np.array([n[2] for n in hi])); 
        print(song,'base',base['principal'],'| margen → (F, notas cambiadas):',res,f'| {dt_:.1f} s','| |fino-detectada| mediana',round(float(np.nanmedian(dev)),3))
