from linea import *
for f in ('mel_bank','onset_envelopes','detect_onsets'):
    exec(open(C+f+'.py').read(), ns)
_bb={}
def bbase(song):
    if song in _bb: return _bb[song]
    b=base(song); n=b['stem'].shape[0]
    bs=np.fromfile(f'{song}.bass.f32',np.float32); bs=np.pad(bs,(0,max(n-len(bs),0)))[:n]
    Sb,cand=ns['pitch_salience'](ns['stft_mag'](bs,NF,HOP),SR,NF)
    isb=cand<=55.0; Sbass=Sb[isb].max(axis=0)
    bass=ns['viterbi_pitch'](Sb[isb],cand[isb],np.percentile(Sbass,55))
    env=ns['onset_envelopes'](bs,SR)
    _bb[song]=dict(bs=bs,bass=bass,Sbass=Sbass,env=env)
    return _bb[song]
def notas_bajo(song, height=0.6, win=0.3, band=1):
    b=bbase(song); J=load(song)[0]; cyc=load(song)[1]
    on=ns['detect_onsets'](b['env'][band],SR/256,height=height,win=win)
    raw=ns['extract_notes'](b['bass'],b['Sbass'],on,SR,HOP,J['off'],50)
    return ns['drop_loose_notes'](raw,cyc), on
if __name__=='__main__':
    for song in SONGS:
        J,cyc,hi,lo,al=load(song)
        raw,on=notas_bajo(song)
        res=[('réplica',len(on),len(J['onsets_b_s']),evaluar(song,hi,raw)['bajo'],'guardada',evaluar(song,hi,lo)['bajo'])]
        for h in (0.5,0.4,0.3,0.2):
            r,on=notas_bajo(song,h); res.append((h,len(on),evaluar(song,hi,r)['bajo']))
        for h in (0.6,0.4):
            r,on=notas_bajo(song,h,band=0); res.append(('banda completa',h,len(on),evaluar(song,hi,r)['bajo']))
        print(song,res)
