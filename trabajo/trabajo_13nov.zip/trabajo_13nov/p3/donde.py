from comun import *
TOL=M.TOL
N=['C','C+','C#','C#+','D','D+','D#','D#+','E','E+','F','F+','F#','F#+','G','G+','G#','G#+','A','A+','A#','A#+','B','B+']
nm=lambda p: N[int(round(2*p))%24]+str(int(round(2*p))//24-1)
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    gu=M.mapped(al,al.ref['guitars']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]
    known=M.in_known(his,al)
    hitj={j for _,j in M.match(lead,known,M.exact)}
    dt=np.array([d[0] for d in known])
    pares=Counter(); secs=Counter(); tot_ref=Counter(); ok_ref=Counter()
    hitk={k for k,_ in M.match(lead,known,M.exact)}
    for k,n in enumerate(lead):
        tot_ref[nm(n['p'])]+=1; ok_ref[nm(n['p'])]+= k in hitk
        lo_,hi_=np.searchsorted(dt,n['t']-TOL),np.searchsorted(dt,n['t']+TOL)
        q=[known[j] for j in range(lo_,hi_) if j not in hitj and abs(abs(known[j][2]-n['p'])-0.5)<0.13]
        if not q: continue
        pares[(nm(n['p']),nm(q[0][2]))]+=1; secs[al.ref['sections'][n['sec']][2][:40]]+=1
    print('==',song, 'errores ¼:',sum(pares.values()))
    print('   partitura→detectada:', [(f'{a}→{b}',v, f'{ok_ref[a]}/{tot_ref[a]} aciertos de {a}') for (a,b),v in pares.most_common(6)])
    print('   secciones:', secs.most_common(4))
