from comun import *
import csv, importlib.util
B='/tmp/claude-0/-home-claude/25e8e225-51e0-5046-8264-de6118f3e1fc/scratchpad/h3/base/references/'
spec=importlib.util.spec_from_file_location('f',B+'fabienk_partitura.py'); R=importlib.util.module_from_spec(spec); spec.loader.exec_module(R)
K=list(csv.DictReader(open('clave_arbitraje.csv')))
song='fabienk'; J,cyc,hi,lo,al=load(song); secs=al.ref['sections']
inv={}
for t,d,p,part in al.ref['notes']: inv.setdefault((round(float(al.t(t)),6),p),[]).append((t,part))
gu=M.mapped(al,al.ref['guitars']); top=M.top_line(gu); sh=M.calib(top,hi); lead=M.lead_line(al,song)
print('unidad', R.SIX, '| primeras secciones:', [(round(a,2),round(b,2),nm[:25]) for a,b,nm,kn in secs[:5]])
for k in K:
    if k['cancion']!=song: continue
    T=float(k['t_audio']); n=min(lead,key=lambda n: abs(n['t']+sh-T))
    for t,part in inv[(round(n['t'],6),n['p'])]:
        i=max(j for j,(t0,t1,nm,kn) in enumerate(secs) if t0<=t+1e-6)
        o=(t-secs[i][0])/R.SIX
        print(k['archivo'],k['tipo'],k['nota_partitura'],'|',secs[i][2][:40],'|',part,'| semicorchea',round(o,2),'| fase en 14:',round(o%14,2),'en 56:',round(o%56,2))
