from bajo2 import *
def regularidad(notes, cycles, tol=0.075):
    """Parte de las notas dentro de ciclos que vuelven igual una vuelta antes o después (sin partitura)."""
    st=np.array([n[0] for n in notes]); pp=np.array([n[2] for n in notes]); spans=[c for g in cycles.values() for c in g]
    tot=ok=0
    for a,b,p in notes:
        cov=[c for c in spans if c.start<=a<c.end]
        if not cov: continue
        P=max(cov,key=lambda c:c.period).period; tot+=1
        ok+= bool(np.any((np.abs(st-(a-P))<tol)&(np.abs(pp-p)<0.26)) or np.any((np.abs(st-(a+P))<tol)&(np.abs(pp-p)<0.26)))
    return ok/max(tot,1), ok
if __name__=='__main__':
    for song in SONGS:
        J,cyc,hi,lo,al=load(song); b=bbase(song); fps=SR/256
        low=lambda h: ns['detect_onsets'](b['env'][1],fps,height=h,win=0.3)
        full=lambda h: ns['detect_onsets'](b['env'][0],fps,height=h,win=0.3)
        res=[]
        for name,on in (('grave 0.6',low(0.6)),('completa 0.8',full(0.8)),('completa 1.0',full(1.0)),('completa 1.2',full(1.2))):
            nt=notas_on(song,on); fr,okn=regularidad(nt,cyc)
            res.append((name,evaluar(song,hi,nt)['bajo'],round(100*fr,1),okn))
        print(song,res)
