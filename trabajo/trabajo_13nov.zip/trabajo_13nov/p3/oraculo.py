from comun import *
TOL=M.TOL
def grupo(notes, i, cycles, tol=0.075, win=0.76):
    a,b,p=notes[i]; st=np.array([n[0] for n in notes])
    best=[]
    for c in [c for g in cycles.values() for c in g if c.start<=a<c.end]:
        P=c.period; g=[]
        for k in range(-12,13):
            if k==0: continue
            t=a+k*P
            if not (c.start-0.05<=t<c.end): continue
            lo_,hi_=np.searchsorted(st,t-tol),np.searchsorted(st,t+tol)
            js=[j for j in range(lo_,hi_) if abs(notes[j][2]-p)<=win]
            if js: g.append(notes[min(js,key=lambda j:abs(st[j]-t))][2])
        if len(g)>len(best): best=g
    return best
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    gu=M.mapped(al,al.ref['guitars']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]
    known=M.in_known(his,al); kset=set(known)
    hit={j for _,j in M.match(lead,known,M.exact)}
    dt=np.array([d[0] for d in known])
    # cuarto de tono: nota de la melodía con una detectada a ±0.5 cerca
    stats=Counter()
    idx={n:i for i,n in enumerate(his)}
    for n in lead:
        lo_,hi_=np.searchsorted(dt,n['t']-TOL),np.searchsorted(dt,n['t']+TOL)
        near=[known[j] for j in range(lo_,hi_) if j not in hit]
        q=[d for d in near if abs(abs(d[2]-n['p'])-0.5)<0.13]
        if not q: continue
        d=q[0]; i=idx[d]
        g=grupo(his,i,cyc)
        votes=Counter(g+[d[2]])
        right=votes.get(round(n['p']*2)/2,0)
        stats['errores 1/4']+=1
        stats['vueltas encontradas>=2']+= len(g)>=2
        stats['la mayoría tiene la altura correcta']+= right> votes[d[2]]
        stats['empate']+= right==votes[d[2]] and right>0
    # aciertos: ¿la mayoría los cambiaría a un cuarto de tono?
    dam=0
    for j in hit:
        d=known[j]; i=idx[d]; g=grupo(his,i,cyc); votes=Counter(g+[d[2]])
        tp,nt=votes.most_common(1)[0]
        if abs(tp-d[2])==0.5 and nt>votes[d[2]]: dam+=1
    print(song, dict(stats), '| aciertos que la mayoría movería:', dam, 'de', len(hit))
