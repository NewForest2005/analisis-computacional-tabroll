from comun import *
from refina import stft
from subarm import whiten
SR,NF,HOP=22050,4096,512
def peak(W,f,fr,win_c=30.0):
    df=SR/NF; kk=f/df; w=max(1,int(np.ceil(kk*(2**(win_c/1200)-1))))
    k0,k1=max(int(round(kk))-w,0),min(int(round(kk))+w+1,W.shape[0])
    return float(W[k0:k1,fr].max(axis=0).mean()) if len(fr) and k1>k0 else 0.0
def dobla(hi, lo, W, off, th, rels=(12,19,24)):
    bst=np.array([n[0] for n in lo]); out=[]; ch=0
    for a,b,p in hi:
        j=np.searchsorted(bst,a+0.075)-1
        q=lo[j][2] if j>=0 and lo[j][0]<=a+0.075 and lo[j][1]>a else None
        if q is not None and any(abs(p-q-r)<0.26 for r in rels):
            fr=np.arange(int(round(a*SR/HOP))+1,max(int(round(b*SR/HOP)),int(round(a*SR/HOP))+2)); fr=fr[fr<W.shape[1]]
            fq=440*2**((q+off-69)/12)
            own=np.mean([peak(W,fq*h,fr) for h in (1,3,5)])            # armónicos impares del bajo: la nota grave misma
            top=np.mean([peak(W,fq*(p-q and 2**((p-q)/12))*h,fr) for h in (1,2)])
            if own/(top+1e-9)>=th: out.append((a,b,q)); ch+=1; continue
        out.append((a,b,p))
    return out,ch
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    W=whiten(stft(np.fromfile(f'{song}.gtr.f32',np.float32)))
    res=[('base',evaluar(song,hi,lo)['principal'])]
    for th in (0.3,0.5,0.7,0.9,1.2):
        new,ch=dobla(hi,lo,W,J['off'],th); res.append((th,evaluar(song,new,lo)['principal'],ch))
    print(song,res)
