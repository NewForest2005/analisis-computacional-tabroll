from comun import *
from refina import stft
from scipy.ndimage import uniform_filter1d
SR=22050; NFFT=4096; HOP=512
def whiten(X):
    Lm=np.log1p(X*20.0); W=np.maximum(Lm-uniform_filter1d(Lm,size=48,axis=0,mode='nearest'),0); return W/(W.max()+1e-9)
def evid(notes, W, off, skip=1, win_c=30.0):
    """Para cada nota: pico medio en los armónicos propios y en los que solo tendría una nota más grave."""
    df=SR/NFFT
    sets={'propios':[1,2,3,4], 'oct':[0.5,1.5,2.5], 'duod':[1/3,2/3,4/3,5/3], 'quinta':[2/3,4/3,8/3,10/3]}
    out=[]
    for a,b,p in notes:
        f=440*2**((p+off-69)/12)
        fr=np.arange(int(round(a*SR/HOP))+skip, max(int(round(b*SR/HOP)), int(round(a*SR/HOP))+skip+1)); fr=fr[fr<W.shape[1]]
        r={}
        for k,hs in sets.items():
            vals=[]
            for h in hs:
                kk=f*h/df; w=max(1,int(np.ceil(kk*(2**(win_c/1200)-1))))
                k0,k1=max(int(round(kk))-w,0),min(int(round(kk))+w+1,W.shape[0])
                vals.append(W[k0:k1,fr].max(axis=0).mean() if len(fr) and k1>k0 else 0.0)
            r[k]=float(np.mean(vals))
        out.append(r)
    return out
def aplica(notes, ev, th, lo_lim=47.0):
    new=[]
    for (a,b,p),e in zip(notes,ev):
        s=e['propios']+1e-9; q=p
        opts=[(e['oct']/s,12,th.get('oct')),(e['duod']/s,19,th.get('duod')),(e['quinta']/s,7,th.get('quinta'))]
        opts=[(r,d) for r,d,t in opts if t is not None and r>=t and p-d>=lo_lim]
        if opts: q=p-max(opts)[1]
        new.append((a,b,q))
    return new
if __name__=='__main__':
    EV={}
    for song in SONGS:
        J,cyc,hi,lo,al=load(song)
        W=whiten(stft(np.fromfile(f'{song}.gtr.f32',np.float32)))
        EV[song]=(hi,lo,evid(hi,W,J['off']))
        base=evaluar(song,hi,lo)['principal']
        print(song,'base',base)
    import itertools
    rows=[]
    for kind in ('oct','duod','quinta'):
        for t in (0.5,0.6,0.7,0.8,0.9,1.0,1.2):
            res=[]
            for song,(hi,lo,ev) in EV.items():
                new=aplica(hi,ev,{kind:t}); ch=sum(1 for u,v in zip(hi,new) if u[2]!=v[2])
                res.append((evaluar(song,new,lo)['principal'],ch))
            rows.append((kind,t,res)); print(kind,t,res)
    import pickle; pickle.dump({s:(v[2]) for s,v in EV.items()},open('ev.pkl','wb'))
