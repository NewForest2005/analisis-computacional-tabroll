from bajo import *
def notas_on(song, on):
    b=bbase(song); J,cyc=load(song)[:2]
    return ns['drop_loose_notes'](ns['extract_notes'](b['bass'],b['Sbass'],on,SR,HOP,J['off'],50),cyc)
def merge(a,b,tol=0.04):
    out=sorted(list(a)); 
    for x in b:
        if not out or np.min(np.abs(np.array(out)-x))>tol: out.append(x)
    return np.array(sorted(out))
for song in SONGS:
    J,cyc,hi,lo,al=load(song); b=bbase(song); fps=SR/256
    low=lambda h: ns['detect_onsets'](b['env'][1],fps,height=h,win=0.3)
    full=lambda h: ns['detect_onsets'](b['env'][0],fps,height=h,win=0.3)
    res=[]
    for name,on in (('grave 0.6',low(0.6)),('completa 0.8',full(0.8)),('completa 1.0',full(1.0)),('completa 1.2',full(1.2)),
                    ('grave 0.6 + completa 1.0',merge(low(0.6),full(1.0))),('grave 0.6 + completa 1.5',merge(low(0.6),full(1.5))),
                    ('grave 0.6 + completa 2.0',merge(low(0.6),full(2.0)))):
        res.append((name,len(on),evaluar(song,hi,notas_on(song,on))['bajo']))
    print(song,res)
