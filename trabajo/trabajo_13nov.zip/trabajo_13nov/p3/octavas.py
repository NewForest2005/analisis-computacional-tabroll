from comun import *
TOL=M.TOL
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    gu=M.mapped(al,al.ref['guitars']); ba=M.mapped(al,al.ref['basses']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]
    known=M.in_known(his,al)
    hitj={j for _,j in M.match(lead,known,M.exact)}
    dt=np.array([d[0] for d in known])
    c=Counter()
    for n in lead:
        lo_,hi_=np.searchsorted(dt,n['t']-TOL),np.searchsorted(dt,n['t']+TOL)
        cand=[known[j] for j in range(lo_,hi_) if j not in hitj]
        q=[d for d in cand if M.pclass(d[2],n['p']) and not M.exact(d[2],n['p'])]
        h=[d for d in cand if any(abs(d[2]-n['p']-x)<0.26 for x in (7,19,-5,-17))]
        sounding=[g for g in gu+ba if g['t']-0.03<=n['t']<g['te']]
        if q:
            d=q[0]; up=d[2]>n['p']
            real=any(M.exact(d[2],g['p']) for g in sounding)
            c[('octava '+('arriba' if up else 'abajo'), 'suena en la partitura' if real else 'no suena')]+=1
        elif h:
            d=h[0]; real=any(M.exact(d[2],g['p']) for g in sounding)
            c[(f'{d[2]-n["p"]:+.0f}', 'suena en la partitura' if real else 'no suena')]+=1
    print(song, sorted(c.items(), key=lambda kv:-kv[1]))
