from comun import *
from refina import stft, fine_pitch
TOL=M.TOL
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    X=stft(np.fromfile(f'{song}.gtr.f32',np.float32))
    gu=M.mapped(al,al.ref['guitars']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]; orig={h:o for h,o in zip(his,hi)}
    known=M.in_known(his,al)
    hitj={j for _,j in M.match(lead,known,M.exact)}
    dt=np.array([d[0] for d in known])
    errs=[]
    for n in lead:
        lo_,hi_=np.searchsorted(dt,n['t']-TOL),np.searchsorted(dt,n['t']+TOL)
        q=[known[j] for j in range(lo_,hi_) if j not in hitj and abs(abs(known[j][2]-n['p'])-0.5)<0.13]
        if q: errs.append((orig[q[0]],n['p']))
    # ventana centrada en el punto medio entre partitura y detectada, ±70 cents: cubre las dos
    mid=[(d[0],d[1],(d[2]+r)/2) for d,r in errs]
    fe=fine_pitch(mid,X,J['off'],win_c=70.0)
    pos=np.array([100*(f-r)*np.sign(d[2]-r) for f,(d,r) in zip(fe,errs)])   # 0 = partitura, 50 = detectada
    print(song,'| errores ¼ (ventana que cubre las dos alturas): cents desde la partitura hacia la detectada, p25/mediana/p75:',
          np.round(np.nanpercentile(pos,[25,50,75])).astype(int).tolist(), '| más cerca de la detectada:', round(100*np.nanmean(pos>25)),'%')
