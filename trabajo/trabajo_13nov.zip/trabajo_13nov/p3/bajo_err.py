from comun import *
TOL=M.TOL
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    ba=M.mapped(al,al.ref['basses']); gu=M.mapped(al,al.ref['guitars']); low=M.top_line(ba,low=True)
    sb=M.calib(low,lo); los=M.in_known([(a-sb,b-sb,p) for a,b,p in lo],al)
    hit=M.match(low,los,M.exact); hk={k for k,_ in hit}; hj={j for _,j in hit}
    dt=np.array([d[0] for d in los]); c=Counter(); iv=Counter()
    for k,n in enumerate(low):
        if k in hk: c['acierto']+=1; continue
        lo_,hi_=np.searchsorted(dt,n['t']-TOL),np.searchsorted(dt,n['t']+TOL)
        near=[los[j] for j in range(lo_,hi_) if j not in hj]
        if any(M.pclass(d[2],n['p']) for d in near): c['octava']+=1; iv['oct '+('+' if near[0][2]>n['p'] else '-')]+=1
        elif any(abs(abs(d[2]-n['p'])-0.5)<0.13 for d in near): c['cuarto']+=1
        elif near: c['otra altura']+=1; iv[round(near[0][2]-n['p'])]+=1
        else:
            sus=[d for d in los if d[0]<n['t']-TOL and d[1]>n['t'] and M.exact(d[2],n['p'])]
            c['re-ataque' if sus else 'no detectada']+=1
    tot=len(low)
    print(song,'bajo F',evaluar(song,hi,lo)['bajo'],{k:round(100*v/tot,1) for k,v in c.most_common()}, '| intervalos:',iv.most_common(6))
