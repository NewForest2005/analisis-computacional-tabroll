from comun import *
TOL=M.TOL
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    off=J['off']; hop=J['hop']/J['sample_rate']
    mel=np.array([np.nan if v is None else v for v in J['melody_n']])
    gu=M.mapped(al,al.ref['guitars']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]; orig={h:o for h,o in zip(his,hi)}
    known=M.in_known(his,al)
    hitj={j for _,j in M.match(lead,known,M.exact)}
    dt=np.array([d[0] for d in known])
    def fine(d):
        a,b,p=orig[d]; f0,f1=int(round(a/hop)),max(int(round(b/hop)),int(round(a/hop))+1)
        v=mel[f0:f1]; v=v[np.isfinite(v)]
        return (np.median(v)-off) if len(v) else np.nan
    def entre(x): return abs(((x/0.5)%1)-0.5)<0.02
    c=Counter(); sign=Counter()
    for n in lead:
        lo_,hi_=np.searchsorted(dt,n['t']-TOL),np.searchsorted(dt,n['t']+TOL)
        q=[known[j] for j in range(lo_,hi_) if j not in hitj and abs(abs(known[j][2]-n['p'])-0.5)<0.13]
        if not q: continue
        f=fine(q[0]); c['err']+=1; c['err_entre']+=entre(f)
        sign['sube' if q[0][2]>n['p'] else 'baja']+=1
    for j in hitj:
        f=fine(known[j]); c['hit']+=1; c['hit_entre']+=entre(f)
    print(song,'off',round(off,3), dict(c), dict(sign), f"| errores ¼ entre casillas: {100*c['err_entre']/max(c['err'],1):.0f}% ; aciertos entre casillas: {100*c['hit_entre']/c['hit']:.0f}%")
