from comun import *
TOL=M.TOL
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    off=J['off']; hop=J['hop']/J['sample_rate']
    mel=np.array([np.nan if v is None else v for v in J['melody_n']])
    gu=M.mapped(al,al.ref['guitars']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]; orig={h:o for h,o in zip(his,hi)}
    known=M.in_known(his,al)
    hitj={j for _,j in M.match(lead,known,M.exact)}
    dt=np.array([d[0] for d in known])
    def frames(d):
        a,b,p=orig[d]; f0,f1=int(round(a/hop)),max(int(round(b/hop)),int(round(a/hop))+1)
        v=mel[f0:f1]; return v[np.isfinite(v)]-off
    H_err=Counter(); H_hit=Counter(); frac_err=[]; frac_hit=[]
    for n in lead:
        lo_,hi_=np.searchsorted(dt,n['t']-TOL),np.searchsorted(dt,n['t']+TOL)
        q=[known[j] for j in range(lo_,hi_) if j not in hitj and abs(abs(known[j][2]-n['p'])-0.5)<0.13]
        if not q: continue
        v=frames(q[0]); 
        # fracción de cuadros de la nota que están en la casilla correcta (a ±0.25 de la referencia)
        frac_err.append(np.mean(np.abs(v-n['p'])<0.26)); H_err[round(float(np.median(v)-q[0][2])*4)/4]+=1
    for j in hitj:
        v=frames(known[j]); frac_hit.append(np.mean(np.abs(v-known[j][2])<0.26)); H_hit[round(float(np.median(v)-known[j][2])*4)/4]+=1
    fe=np.array(frac_err); fh=np.array(frac_hit)
    print(song,'| errores ¼: cuadros en la altura correcta, mediana',round(float(np.median(fe)),2),'; con >=30%:',round(100*np.mean(fe>=0.3)),'%',
          '| aciertos: cuadros en su altura, mediana',round(float(np.median(fh)),2))
    print('   mediana-cuadros menos altura detectada (errores):',sorted(H_err.items()))
