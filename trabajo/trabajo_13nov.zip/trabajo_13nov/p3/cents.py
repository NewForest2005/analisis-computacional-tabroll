from comun import *
from refina import stft, fine_pitch
TOL=M.TOL
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    X=stft(np.fromfile(f'{song}.gtr.f32',np.float32))
    gu=M.mapped(al,al.ref['guitars']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]; orig={h:o for h,o in zip(his,hi)}
    known=M.in_known(his,al)
    hitj={j for _,j in M.match(lead,known,M.exact)}
    dt=np.array([d[0] for d in known])
    errs=[]; 
    for n in lead:
        lo_,hi_=np.searchsorted(dt,n['t']-TOL),np.searchsorted(dt,n['t']+TOL)
        q=[known[j] for j in range(lo_,hi_) if j not in hitj and abs(abs(known[j][2]-n['p'])-0.5)<0.13]
        if q: errs.append((orig[q[0]],n['p']))
    fe=fine_pitch([e[0] for e in errs],X,J['off'])
    dev_ref=np.array([100*(f-r) * np.sign(d[2]-r) for f,(d,r) in zip(fe,errs)])     # cents desde la partitura hacia la detectada
    hits=[orig[known[j]] for j in hitj]; fh=fine_pitch(hits,X,J['off'])
    dev_hit=100*(fh-np.array([h[2] for h in hits]))
    q=lambda v: np.round(np.nanpercentile(v,[25,50,75])).astype(int).tolist()
    print(song, '| errores ¼, cents desde la partitura hacia la detectada (p25, mediana, p75):', q(dev_ref),
          '| aciertos, cents desde su casilla:', q(dev_hit))
