from comun import *
import csv, importlib.util
B='/tmp/claude-0/-home-claude/25e8e225-51e0-5046-8264-de6118f3e1fc/scratchpad/h3/base/references/'
def refmod(name):
    spec=importlib.util.spec_from_file_location(name,B+name+'.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
MODS={'sarniezz':('sarniezz_partitura',48),'fabienk':('fabienk_partitura',None),'mata_zyklek':('mata_zyklek_loops',None)}
K=list(csv.DictReader(open('clave_arbitraje.csv')))
for song in ('sarniezz','fabienk'):
    J,cyc,hi,lo,al=load(song); R=refmod(MODS[song][0])
    secs=al.ref['sections']
    # unidad (s por corchea o semicorchea) de cada sección
    unit=[]
    for s in R.SECTIONS:
        unit.append(s[2] if song=='sarniezz' else R.SIX)
    inv={}
    for t,d,p,part in al.ref['notes']: inv.setdefault((round(float(al.t(t)),6),p),[]).append((t,part))
    gu=M.mapped(al,al.ref['guitars']); top=M.top_line(gu); sh=M.calib(top,hi); lead=M.lead_line(al,song)
    for k in K:
        if k['cancion']!=song: continue
        T=float(k['t_audio'])
        n=min(lead,key=lambda n: abs(n['t']+sh-T))
        t,part=inv[(round(n['t'],6),n['p'])][0]
        i=max(j for j,(t0,t1,nm,kn) in enumerate(secs) if t0<=t+1e-6)
        o=round((t-secs[i][0])/unit[i],2)
        print(k['archivo'],k['tipo'],k['nota_partitura'],'|',secs[i][2][:45],'|',part,'| unidad',o, ('| posición en P1: '+str(o%48)) if song=='sarniezz' else '')
