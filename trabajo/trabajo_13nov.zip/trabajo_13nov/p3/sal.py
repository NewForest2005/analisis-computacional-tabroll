from comun import *
TOL=M.TOL
for song in SONGS:
    J,cyc,hi,lo,al=load(song)
    off=J['off']; hop=J['hop']/J['sample_rate']
    S=np.array(J['selector_salience'],dtype=float); cand=np.array(J['cand_ishigh'])
    gu=M.mapped(al,al.ref['guitars']); lead=M.lead_line(al,song); top=M.top_line(gu)
    sh=M.calib(top,hi); his=[(a-sh,b-sh,p) for a,b,p in hi]; orig={h:o for h,o in zip(his,hi)}
    known=M.in_known(his,al)
    hitj={j for _,j in M.match(lead,known,M.exact)}
    dt=np.array([d[0] for d in known])
    def sal(d, p):
        a,b,_=orig[d]; f0,f1=int(round(a/hop)),max(int(round(b/hop)),int(round(a/hop))+1)
        r=int(np.argmin(np.abs(cand-(p+off))))
        return float(S[max(r-1,0):r+2, f0:f1].max(axis=0).mean())   # pico en ±1 candidato (±25 cents)
    ratio_err=[]; ratio_hit=[]
    for n in lead:
        lo_,hi_=np.searchsorted(dt,n['t']-TOL),np.searchsorted(dt,n['t']+TOL)
        q=[known[j] for j in range(lo_,hi_) if j not in hitj and abs(abs(known[j][2]-n['p'])-0.5)<0.13]
        if not q: continue
        d=q[0]; ratio_err.append(sal(d,n['p'])/max(sal(d,d[2]),1e-12))
    for j in hitj:
        d=known[j]
        for alt in (d[2]-0.5,d[2]+0.5):
            ratio_hit.append(sal(d,alt)/max(sal(d,d[2]),1e-12))
    re_=np.array(ratio_err); rh=np.array(ratio_hit)
    print(song,'| errores ¼: saliencia en la altura correcta / en la detectada: mediana',round(float(np.median(re_)),2),
          '| >1 (la correcta pesa más):',round(100*np.mean(re_>1)),'%',
          '| aciertos: vecina a ¼ / detectada: mediana',round(float(np.median(rh)),2),' >1:',round(100*np.mean(rh>1)),'%')
