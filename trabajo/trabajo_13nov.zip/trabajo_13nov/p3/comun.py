import sys, json, glob
import numpy as np
from types import SimpleNamespace
from collections import Counter
sys.path.insert(0,'/tmp/claude-0/-home-claude/25e8e225-51e0-5046-8264-de6118f3e1fc/scratchpad/h3/base/src')
import tabroll.evaluation.melodia as M
R='/tmp/claude-0/-home-claude/25e8e225-51e0-5046-8264-de6118f3e1fc/scratchpad/runs_repro/outputs/'
SONGS={'sarniezz':'*sarniezz*_repro','mata_zyklek':'*mata_zyklek*_repro','fabienk':'*fabienk*_repro'}
_cache={}
def load(song):
    if song in _cache: return _cache[song]
    J=json.load(open(glob.glob(R+SONGS[song]+'/line_diagnostics.json')[0]))
    cyc={v:[SimpleNamespace(start=c['start_s'],end=c['end_s'],period=c['period_s']) for c in cs] for v,cs in J['cycles_n'].items()}
    hi=M._notes(J['raw_high']); lo=M._notes(J['raw_bass'])
    al=M.Alignment(song)
    _cache[song]=(J,cyc,hi,lo,al)
    return _cache[song]
def evaluar(song, hi, lo):
    r=M.evaluate(song, hi, lo)
    return {k:round(r[k],1) for k in ('principal','principal_sin_octava','mas_aguda','bajo')} | {'det':r['notas_detectadas']}
