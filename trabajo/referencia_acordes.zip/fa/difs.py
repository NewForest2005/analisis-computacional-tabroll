import sys, collections, numpy as np
sys.path.insert(0,'../main/src'); import tabroll.evaluation.melodia as M
import validar as V
for c in sys.argv[1:]:
    G=V.cargar(c,'_fina'); gt=np.array([g[0] for g in G]); gp=np.array([g[2] for g in G])
    al=M.Alignment(c); ref=M.mapped(al,al.ref['guitars']+al.ref['basses']); secs=al.ref['sections']
    D=collections.Counter(); porparte=collections.defaultdict(collections.Counter)
    for n in ref:
        i0,i1=np.searchsorted(gt,n['t']-0.075),np.searchsorted(gt,n['t']+0.075)
        if i1==i0: k='sin nota de GP a ±75 ms'
        else:
            d=gp[i0:i1]-n['p']; j=np.argmin(np.abs(d)); k='igual' if abs(d[j])<0.26 else ('%+.1f'%d[j] if abs(d[j])<=2 else ('octava' if abs(abs(d[j])-12)<0.26 or abs(abs(d[j])-24)<0.26 else 'otra'))
            if k not in('igual',) and np.any(np.abs((d+6)%12-6)<0.26): k='misma clase, otra octava'
        D[k]+=1; porparte[n['part']][k]+=1
    tot=sum(D.values()); print(c,{k:f'{100*v/tot:.1f}%' for k,v in D.most_common(12)})
    for p,v in porparte.items():
        t=sum(v.values()); print('   ',p,t,{k:f'{100*x/t:.0f}%' for k,x in v.most_common(6)})
