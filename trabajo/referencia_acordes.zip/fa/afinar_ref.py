"""Fase A: afina el mapa render → grabación con la referencia corregida de oído: en ventanas de 6 s, el desfase mediano
entre cada nota de la referencia corregida (ya alineada con la grabación) y la misma nota de Guitar Pro. Solo corrige el
tiempo del mapa; no toca alturas ni notas."""
import sys, json, numpy as np
from scipy.ndimage import median_filter
sys.path.insert(0,'../main/src'); import tabroll.evaluation.melodia as M
import validar as V
def afinar(c, win=6.0, hop=3.0, vueltas=3):
    J=json.load(open(f'{c}_pistas_alineacion.json')); s=np.array(J['partitura_s']); a=np.array(J['audio_s'])
    al=M.Alignment(c); ref=M.mapped(al,al.ref['guitars']+al.ref['basses'])
    rt=np.array([n['t'] for n in ref]); rp=np.array([n['p'] for n in ref])
    import csv
    G=[(float(r['inicio_s']),float(r['altura'])) for r in csv.DictReader(open(f'{c}_pistas.csv'))]
    gs=np.array([g[0] for g in G]); gp=np.array([g[1] for g in G]); o=np.argsort(gs); gs,gp=gs[o],gp[o]
    for v in range(vueltas):
        ga=np.interp(gs,s,a); o2=np.argsort(ga); gas,gps,gss=ga[o2],gp[o2],gs[o2]
        ds=[]; ss=[]
        for t,p in zip(rt,rp):
            i0,i1=np.searchsorted(gas,t-0.2),np.searchsorted(gas,t+0.2)
            m=np.abs(gps[i0:i1]-p)<0.26
            if m.any():
                d=t-gas[i0:i1][m]; k=np.argmin(np.abs(d)); ds.append(d[k]); ss.append(gss[i0:i1][m][k])
        ds=np.array(ds); ss=np.array(ss); cen=[]; lag=[]
        for t0 in np.arange(s[0],s[-1],hop):
            m=(ss>=t0)&(ss<t0+win)
            cen.append(t0+win/2); lag.append(np.median(ds[m]) if m.sum()>=8 else np.nan)
        lag=np.array(lag); ok=np.isfinite(lag)
        lag[~ok]=np.interp(np.array(cen)[~ok],np.array(cen)[ok],lag[ok]); lag=median_filter(lag,3,mode='nearest')
        a=a+np.interp(s,cen,lag)
        print('  vuelta',v+1,'corrección mediana %.0f ms, máx %.0f ms, pares %d'%(1000*np.median(np.abs(lag)),1000*np.abs(lag).max(),len(ds)))
    J['audio_s']=[round(float(x),4) for x in a]
    J['nota']+=' Afinado después con la referencia corregida de oído: en ventanas de 6 s, el desfase mediano entre las notas comunes.'
    json.dump(J,open(f'{c}_pistas_alineacion_fina.json','w'),ensure_ascii=False)
if __name__=='__main__':
    for c in sys.argv[1:]:
        afinar(c); V.comparar(c,'_fina')
