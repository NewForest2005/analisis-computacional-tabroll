"""Fase A: referencia de acordes completa, en tiempo de la grabación oficial.
= las notas de la referencia corregida de oído (mandan) + las notas de las demás pistas de la partitura de Guitar Pro.
Una nota de Guitar Pro entra solo si la referencia corregida no tiene, a ±75 ms, una nota de la misma clase de altura o
a menos de un tono (esa sería la misma nota, ya corregida) y si no es una nota que el autor quitó de oído.
Escribe references/completas/<canción>.csv: inicio_s, fin_s, altura (sonora), parte, origen."""
import sys, csv, collections, numpy as np
sys.path.insert(0,'../main/src'); import tabroll.evaluation.melodia as M
import validar as V
TOL=0.075
def quitadas(c, al):
    """Notas quitadas de oído (si la referencia las declara), en tiempo de la grabación."""
    R=M._module(M.REFS/{'fabienk':'fabienk_partitura.py','sarniezz':'sarniezz_partitura.py','mata_zyklek':'mata_zyklek_loops.py'}[c])
    Q=getattr(R,'QUITADAS_DE_OIDO',None)
    if not Q or c!='fabienk': return []
    out=[]; t=0
    for name,n,P_,known in R.SECTIONS:
        for pre,parts in Q.items():
            if name.startswith(pre):
                for part,notes in parts.items():
                    out+=[(float(al.t((t+o)*R.SIX)),p+R.TRANSPOSE[part]) for o,d,p in notes if o<n]
        t+=n
    return out
def unir(c, out_dir='../main/references/completas'):
    al=M.Alignment(c); secs=al.ref['sections']
    ref=M.mapped(al,al.ref['guitars']+al.ref['basses'])
    spans=[(float(al.t(t0)),float(al.t(t1))) for t0,t1,nm,kn in secs if kn]
    rt=np.array([n['t'] for n in ref]); rp=np.array([n['p'] for n in ref])
    Q=quitadas(c,al); qt=np.array([q[0] for q in Q]); qp=np.array([q[1] for q in Q])
    G=V.cargar(c,'_fina'); cuenta=collections.Counter(); extra=[]
    for t,te,p,part,compas in G:
        if not any(a<=t<b for a,b in spans): cuenta['fuera de tramos medibles']+=1; continue
        i0,i1=np.searchsorted(rt,t-TOL),np.searchsorted(rt,t+TOL)
        d=rp[i0:i1]-p
        if len(d) and np.any((np.abs(d)<=2.01)|(np.abs((d+6)%12-6)<0.26)): cuenta['ya está en la corregida']+=1; continue
        if len(Q) and np.any((np.abs(qt-t)<=TOL)&(np.abs((qp-p+6)%12-6)<0.76)): cuenta['quitada de oído']+=1; continue
        if part=='B': cuenta['bajo de Guitar Pro distinto (no entra)']+=1; continue      # el bajo es una sola voz: manda la corregida
        cuenta['añadida']+=1; cuenta['añadida '+part]+=1; extra.append((t,te,p,('B' if part=='B' else 'G')+'x',f'guitar pro {part}'))
    filas=[(n['t'],n['te'],n['p'],n['part'],'corregida de oído') for n in ref]+extra
    filas.sort()
    import os; os.makedirs(out_dir,exist_ok=True)
    with open(f'{out_dir}/{c}.csv','w',newline='',encoding='utf-8') as fh:
        w=csv.writer(fh); w.writerow(['inicio_s','fin_s','altura','parte','origen'])
        for t,te,p,part,o in filas: w.writerow([f'{t:.4f}',f'{te:.4f}',f'{p:g}',part,o])
    # la partitura de Guitar Pro sola (todas las pistas, sin corregir), y los tramos de la grabación donde el mapa es regular
    import json
    J=json.load(open(f'{c}_pistas_alineacion_fina.json')); ps=np.array(J['partitura_s']); pa=np.array(J['audio_s'])
    with open(f'{out_dir}/{c}_guitar_pro.csv','w',newline='',encoding='utf-8') as fh:
        w=csv.writer(fh); w.writerow(['inicio_s','fin_s','altura','parte','origen'])
        for t,te,p,part,compas in G: w.writerow([f'{t:.4f}',f'{te:.4f}',f'{p:g}',part,f'guitar pro c. {compas}'])
    tr=[]; g=np.arange(pa[0],pa[-1],0.5)
    inv=np.interp(g,pa,ps); pend=(np.interp(g+3,pa,ps)-inv)/3
    ok=(pend>0.85)&(pend<1.18); ini=None
    for t,o in zip(g,ok):
        if o and ini is None: ini=t
        if not o and ini is not None:
            if t+3-ini>=4: tr.append([round(float(ini),2),round(float(t+3),2)])
            ini=None
    if ini is not None: tr.append([round(float(ini),2),round(float(g[-1]+0.5),2)])
    # une tramos que se tocan
    un=[]
    for a_,b_ in tr:
        if un and a_<=un[-1][1]: un[-1][1]=max(un[-1][1],b_)
        else: un.append([a_,b_])
    json.dump(dict(cancion=c,tramos_guitar_pro=un,nota='Tramos de la grabación (s) donde el mapa partitura de Guitar Pro → grabación avanza al mismo paso (pendiente entre 0.85 y 1.18): solo ahí se compara con la partitura de Guitar Pro sola.'),
              open(f'{out_dir}/{c}.json','w'),ensure_ascii=False,indent=1)
    print(c,'corregidas',len(ref),dict(cuenta),'| tramos GP: %.0f s de %.0f'%(sum(b-a for a,b in un),pa[-1]-pa[0]),un[:8])
if __name__=='__main__':
    for c in sys.argv[1:]: unir(c)
