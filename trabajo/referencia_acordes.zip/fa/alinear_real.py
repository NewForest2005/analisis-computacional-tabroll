"""Fase A: alinea el render de la partitura de Guitar Pro (suma de guitarras y bajo) con la grabación oficial (pistas de
guitarra y bajo de Demucs, semilla 0): DTW sobre croma de cuartos de tono y afinado con los ataques."""
import sys, json, numpy as np
sys.path.append('../yz'); import dtw as D
from scipy.ndimage import median_filter
SR=22050
def flujo(x, n=1024, hop=220):
    from numpy.lib.stride_tricks import sliding_window_view
    fr=sliding_window_view(x,n)[::hop]; w=np.hanning(n).astype(np.float32); out=[]; prev=None
    for s in range(0,len(fr),4000):
        L=np.log1p(100*np.abs(np.fft.rfft(fr[s:s+4000]*w,axis=1)))
        if prev is not None: L=np.vstack([prev,L])
        d=np.maximum(np.diff(L,axis=0),0).sum(axis=1); out.append(d if prev is not None else np.concatenate([[0],d])); prev=L[-1:]
    f=np.concatenate(out); return (f-f.mean())/(f.std()+1e-9), hop/SR
def alinear(c):
    r=np.fromfile(f'mix_{c}.f32',np.float32)
    a=np.fromfile(f'../p3/{c}.gtr.f32',np.float32); b=np.fromfile(f'../p3/{c}.bass.f32',np.float32); n=min(len(a),len(b)); a=a[:n]+b[:n]
    Cs,Ca=D.croma24(r),D.croma24(a)
    path,cost=D.dtw(Cs,Ca,ventana=20.0)
    ps=np.array([p[0] for p in path]); pa=np.array([p[1] for p in path])
    borr=np.zeros(len(Cs),bool)
    for (i0,j0),(i1,j1) in zip(path[:-1],path[1:]):
        if i1-i0>j1-j0: borr[i0+1:i0+1+(i1-i0)-(j1-j0)]=True
    borr[:ps[0]]=True; borr[ps[-1]+1:]=True
    cp=np.array([cost[i,j] for i,j in path])
    s=ps*D.DT; au=pa*D.DT
    print(c,'cuadros render',len(Cs),'audio',len(Ca),'inicio %.1f→%.1f fin %.1f→%.1f'%(s[0],au[0],s[-1],au[-1]),'borrados %.1f s'%(borr.sum()*D.DT),'costo medio %.3f'%cp.mean())
    # afinado con los ataques, en ventanas de 8 s
    Fr,dtf=flujo(r); Fa,_=flujo(a); WIN=8.0; cen=[]; lags=[]
    for t0 in np.arange(s[0],s[-1],WIN):
        i=np.arange(int(t0/dtf),int(min(t0+WIN,s[-1])/dtf)); base=np.interp(i*dtf,s,au); cs=[]
        for L in range(-30,31):
            j=np.round(base/dtf).astype(int)+L; ok=(j>=0)&(j<len(Fa))&(i<len(Fr))
            cs.append(np.corrcoef(Fr[i[ok]],Fa[j[ok]])[0,1] if ok.sum()>50 else -1)
        k=int(np.argmax(cs)); cen.append(t0+WIN/2); lags.append((k-30)*dtf if cs[k]>0.15 else np.nan)
    lags=np.array(lags); ok=np.isfinite(lags)
    lags[~ok]=np.interp(np.array(cen)[~ok],np.array(cen)[ok],lags[ok]); lags=median_filter(lags,3,mode='nearest')
    au2=au+np.interp(s,cen,lags)
    J=dict(cancion=c,dt=D.DT,partitura_s=[round(float(x),4) for x in s],audio_s=[round(float(x),4) for x in au2],borrado=''.join('1' if x else '0' for x in borr),
           nota='Camino DTW entre el render de la partitura de Guitar Pro (WAV por pista: guitarras y bajo sumados) y la suma de las pistas de '
                'guitarra y bajo separadas por Demucs (semilla 0) del audio oficial; croma de cuartos de tono. Afinado con los ataques en ventanas de 8 s.')
    json.dump(J,open(f'{c}_pistas_alineacion.json','w'),ensure_ascii=False)
    # pendiente local del camino, por tramos de 20 s de render
    print('   pendiente por tramo de 20 s:',' '.join('%.2f'%((np.interp(t+20,s,au2)-np.interp(t,s,au2))/20) for t in np.arange(s[0],s[-1]-20,20)))
    print('   afinado (ms):',np.round(lags*1000).astype(int).tolist())
if __name__=='__main__':
    for c in sys.argv[1:]: alinear(c)
