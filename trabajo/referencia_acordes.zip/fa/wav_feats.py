"""Fase A: ataques y altura (YIN) de cada WAV por pista exportado de Guitar Pro; guarda también la mezcla guitarras+bajo."""
import sys, glob, subprocess, pickle, numpy as np
sys.path.insert(0,'../yz'); import yin as Y
Y.SR=22050
U='/mnt/user-data/uploads/'
CANC={'sarniezz':'Sarniezz','mata_zyklek':'Mata_Zyklek','fabienk':'Fabienk'}
NOMBRE={'Guitae_II':'Guitar_II'}
def leer(f):
    raw=subprocess.run(['ffmpeg','-v','error','-i',f,'-ac','1','-ar','22050','-f','f32le','-'],capture_output=True,check=True).stdout
    return np.frombuffer(raw,np.float32).copy()
for c in sys.argv[1:] or CANC:
    R={}; mix=None
    for f in sorted(glob.glob(U+f'Angine_de_poitrine_-_{CANC[c]}__*_.wav')):
        parte=f.split('__')[1].rstrip('_').rstrip('.wav').rstrip('_'); parte=NOMBRE.get(parte,parte)
        if parte=='Vocals': continue
        x=leer(f)
        on,flux=Y.onsets(x,n=1024,hop=128)
        if parte=='Drums': R[parte]=dict(on=on); print(c,parte,len(on),'ataques'); continue
        bajo=parte=='Bass'
        t,f0,cf,rms=Y.yin(x,frame=2048,hop=128,fmin=28.0 if bajo else 60.0,fmax=300.0 if bajo else 1400.0,thr=0.15 if bajo else 0.45)
        R[parte]=dict(on=on,t=t,f0=f0,conf=cf,rms=rms,dur=len(x)/22050)
        mix=x.copy() if mix is None else mix[:min(len(mix),len(x))]+x[:min(len(mix),len(x))]
        print(c,parte,len(on),'ataques, %.1f s'%(len(x)/22050), 'pico %.2f'%np.abs(x).max(), flush=True)
    pickle.dump(R,open(f'wav_{c}.pkl','wb')); mix.astype(np.float32).tofile(f'mix_{c}.f32')
