"""Fase A: lee la tablatura de todos los PDF por pista de una canción (reusa yz/pdftab.py). Solo evaluación."""
import sys, glob, pickle, collections
sys.path.insert(0,'../yz'); import pdftab as T
A=T.A
CANC={'sarniezz':'Sarniezz','mata_zyklek':'Mata_Zyklek','fabienk':'Fabienk'}
def partes(c):
    fs=sorted(glob.glob(A+f'*Angine_de_Poitrine_-_{CANC[c]}_*.pdf'))
    return {f.split(CANC[c]+'_')[1][:-4]:f for f in fs if 'Drums' not in f and 'Vocals' not in f}
if __name__=='__main__':
    for c in CANC:
        P={}
        for nombre,f in partes(c).items():
            bars=T.parse(f); P[nombre]=bars
            nums=[b['num'] for b in bars]; nn=sum(len(b['notas']) for b in bars)
            saltos=[(a['num'],b['num']) for a,b in zip(bars,bars[1:]) if a['num'] is None or b['num'] is None or b['num']!=a['num']+a['compases']]
            raros=collections.Counter(n.get('raro') for b in bars for n in b['notas'] if n.get('raro'))
            tempos=[(b['num'],b['tempo']) for b in bars if b['tempo']]
            secs=[(b['num'],b['seccion']) for b in bars if b['seccion']]
            print(c,nombre,'compases',len(bars),'último',nums[-1],'+',bars[-1]['compases'],'notas',nn,'cuerdas',set(b['cuerdas'] for b in bars),
                  'saltos',saltos[:6],'raros',dict(raros),'tempos',tempos[:6])
            if nombre in('Guitar_I','Bass'): print('   secciones',secs[:30])
        pickle.dump(P,open(f'pdf_{c}.pkl','wb'))
