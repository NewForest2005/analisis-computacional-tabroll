import sys, glob, json; sys.path.insert(0,'../main/src')
from pathlib import Path
from tabroll.evaluation import armonia as A
out={}
for c in ('mata_zyklek','sarniezz','fabienk'):
    run=Path(glob.glob(f'../runs_repro/outputs/*{c}*_repro')[0])
    r=A.evaluate_run(run,c,write=False); rc=r['referencias']; out[c]=rc
    print(c,'| de siempre: fundamental',r['fundamental'],'f+calidad',r['fundamental_y_calidad'],'bajo',r['bajo'],'compases',r['compases_medidos'])
    for k,v in rc.items():
        if k not in('cancion','compases'): print('   ',k,v)
json.dump(out,open('referencias_resultado.json','w'),ensure_ascii=False,indent=1)
