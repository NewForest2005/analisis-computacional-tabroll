"""Fase A: empareja los ataques de la tablatura (PDF) con los del WAV de su pista (secuencias, costo por altura)."""
import sys, pickle, numpy as np
sys.path.append('../yz'); import alinear_wav as AW
def emparejar(c, verbose=True):
    P=pickle.load(open(f'pdf_{c}.pkl','rb')); W=pickle.load(open(f'wav_{c}.pkl','rb')); res={}
    for parte in P:
        if parte not in W: print('sin WAV:',parte); continue
        ev,lig=AW.eventos_pdf(P[parte])
        on=W[parte]['on']; med=AW.altura_ataque(W[parte],on)
        C=AW.costo(ev,med)
        pares,tot=AW.alinear(C,gracia=np.array([e['gracia'] for e in ev]))
        ok=[(i,j) for i,j in pares if C[i,j]<1.0]
        for i,j in pares:
            ev[i]['t']=float(on[j]); ev[i]['med']=float(med[j]); ev[i]['c']=float(C[i,j])
        res[parte]=dict(ev=ev,lig=lig)
        dif=np.array([ev[i]['med']-max(ev[i]['alturas']) for i,j in ok if ev[i]['alturas'] and len(ev[i]['notas'])==1])
        nm=sum(1 for e in ev if e['muerta']); ng=sum(1 for e in ev if e['gracia'])
        if verbose: print(c,parte,'eventos PDF',len(ev),f'(muertas {nm}, adorno {ng})','ataques WAV',len(on),'pareados',len(pares),'buenos',len(ok),
              'medido-escrito: mediana %+.2f, |dif|>0.5: %d'%(np.nanmedian(dif) if len(dif) else np.nan,int(np.sum(np.abs(dif-np.nanmedian(dif))>0.5)) if len(dif) else 0))
    pickle.dump(res,open(f'par_{c}.pkl','wb')); return res
if __name__=='__main__':
    for c in sys.argv[1:]: emparejar(c)
