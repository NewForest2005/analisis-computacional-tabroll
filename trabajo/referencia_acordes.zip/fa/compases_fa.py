"""Fase A: inicio de cada compás en el tiempo del render, a partir de los ataques emparejados que caen en el primer tiempo."""
import sys, pickle, collections, numpy as np
def anclas(c):
    A=pickle.load(open(f'par_{c}.pkl','rb')); P=pickle.load(open(f'pdf_{c}.pkl','rb'))
    votos=collections.defaultdict(list); rango=collections.defaultdict(list)
    for parte in A:
        bars=P[parte]
        sf=[i==0 or bars[i]['x0']<bars[i-1]['x0'] for i in range(len(bars))]
        dxs={True:[],False:[]}
        for i,b in enumerate(bars):
            if b['notas']: dxs[sf[i]].append(min(n['x'] for n in b['notas'])-b['x0'])
        ref={k:(np.percentile(v,5) if v else None) for k,v in dxs.items()}
        for e in A[parte]['ev']:
            if 't' not in e or e['c']>=1.0 or e['num'] is None: continue
            b=bars[e['bi']]; rango[e['num']].append(e['t'])
            r=ref[sf[e['bi']]]
            if r is not None and e['x']-b['x0']<=r+2.5 and not e['gracia']:
                votos[e['num']].append((e['t'],parte))
    return votos,rango,P
def inicios(c, verbose=False):
    votos,rango,P=anclas(c)
    nb=max(max(b['num']+b['compases']-1 for b in bars if b['num']) for bars in P.values())
    T={}
    for b,v in votos.items():
        ts=np.array(sorted(t for t,_ in v))
        # el grupo más numeroso dentro de 30 ms; si hay empate, el más temprano
        best=max(((np.sum(np.abs(ts-t)<0.03),-t) for t in ts)); T[b]=float(np.median(ts[np.abs(ts+best[1])<0.03])); 
    return T,rango,nb
if __name__=='__main__':
    c=sys.argv[1]; T,rango,nb=inicios(c)
    nums=sorted(T); print(c,'compases',nb,'con ancla',len(nums),'primero',nums[0],round(T[nums[0]],3))
    L=collections.Counter(); raros=[]
    for a,b in zip(nums[:-1],nums[1:]):
        d=(T[b]-T[a])/(b-a); L[round(d,2)]+=1
        if b-a>1: raros.append((a,b,round(d,3)))
    print(sorted(L.items())); print('huecos',raros[:40])
