"""Fase A: compara, en tiempo de la grabación, las notas de todas las pistas de Guitar Pro con la referencia corregida
de oído (que tiene menos pistas). Sirve para validar la alineación y ver qué tan de acuerdo están las dos transcripciones."""
import sys, csv, json, collections, numpy as np
from pathlib import Path
sys.path.insert(0,'../main/src'); import tabroll.evaluation.melodia as M
def cargar(c, sufijo=''):
    J=json.load(open(f'{c}_pistas_alineacion{sufijo}.json')); s=np.array(J['partitura_s']); a=np.array(J['audio_s'])
    borr=np.array([x=='1' for x in J['borrado']]); dt=J['dt']
    R=[]
    for r in csv.DictReader(open(f'{c}_pistas.csv')):
        t=float(r['inicio_s']); d=float(r['duracion_s'])
        if t<s[0] or t>s[-1] or borr[min(int(t/dt),len(borr)-1)]: continue
        R.append((float(np.interp(t,s,a)),float(np.interp(t+d,s,a)),float(r['altura']),r['parte'],int(r['compas'])))
    return sorted(R)
def comparar(c, sufijo='', verbose=True):
    G=cargar(c,sufijo); gt=np.array([g[0] for g in G]); gp=np.array([g[2] for g in G])
    al=M.Alignment(c); ref=M.mapped(al,al.ref['guitars']+al.ref['basses'])
    secs=al.ref['sections']; res=collections.defaultdict(lambda:[0,0,[]])
    for n in ref:
        i0,i1=np.searchsorted(gt,n['t']-0.25),np.searchsorted(gt,n['t']+0.25)
        m=np.abs(gp[i0:i1]-n['p'])<0.26
        key=secs[n['sec']][2][:44]
        res[key][1]+=1
        if m.any():
            d=gt[i0:i1][m]-n['t']; d=d[np.argmin(np.abs(d))]; res[key][2].append(d)
            if abs(d)<=0.075: res[key][0]+=1
    tot=sum(v[1] for v in res.values()); ok=sum(v[0] for v in res.values())
    if verbose:
        for k,(a,b,d) in res.items():
            print('   %-46s %4d/%4d = %3.0f %%   desfase mediano %+4.0f ms'%(k,a,b,100*a/max(b,1),1000*np.median(d) if d else np.nan))
    print(c,sufijo,'notas de la referencia corregida que también están en Guitar Pro (±75 ms, misma altura): %d/%d = %.1f %%'%(ok,tot,100*ok/tot))
    return res
if __name__=='__main__':
    for c in sys.argv[1:]: comparar(c)
