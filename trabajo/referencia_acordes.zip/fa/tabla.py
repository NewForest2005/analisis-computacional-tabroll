"""Fase A: tabla de notas de TODAS las pistas de la partitura de Guitar Pro (solo evaluación).
Altura, cuerda, traste, bend y compás: de la tablatura del PDF. Tiempo: del WAV que Guitar Pro exporta de esa pista.
- Un ataque del PDF emparejado con un ataque del WAV toma su tiempo (medido = 1).
- Lo que no tiene ataque en el WAV (ligados, notas repetidas que el detector no separa) se interpola por su posición
  horizontal entre los vecinos medidos de la misma pista y va a la fusa más cercana contada desde el vecino anterior.
- Las notas de adorno y las notas muertas no entran. Un ligado sin cambio de altura se suma a su nota.
- Duración: hasta el siguiente ataque de la pista, o hasta que el nivel del WAV cae 20 dB bajo el del ataque.
Tiempos en segundos del render (t = 0 al empezar el WAV). Alturas SONORAS en MIDI con cuartos de tono."""
import sys, pickle, csv, collections, numpy as np
sys.path.append('../yz'); import alinear_wav as AW
import rejilla as RJ
FUSA={'sarniezz':4,'mata_zyklek':4,'fabienk':2}        # fusas por unidad de la rejilla (corchea, corchea, semicorchea)
PN={'Guitar_I':'G1','Guitar_II':'G2','Guitar_III':'G3','Guitar_IV':'G4','Guitar_V':'G5','Guitar_VI':'G6','Bass':'B'}

def construir(c):
    P=pickle.load(open(f'pdf_{c}.pkl','rb')); W=pickle.load(open(f'wav_{c}.pkl','rb')); A=pickle.load(open(f'par_{c}.pkl','rb'))
    u,ph=RJ.rejilla(c,verbose=False); g=u/FUSA[c]
    filas=[]; info={}
    for parte in sorted(A, key=lambda p: list(PN).index(p)):
        bars=P[parte]; ev,lig=A[parte]['ev'],A[parte]['lig']
        L0=np.concatenate([[0],np.cumsum([b['x1']-b['x0'] for b in bars])])       # coordenada de maquetación acumulada
        coord=lambda bi,x: L0[bi]+(x-bars[bi]['x0'])
        items=[]
        for e in ev:
            if e['gracia'] or e['muerta'] or not e['alturas']: continue
            ok='t' in e and e['c']<1.0
            items.append(dict(L=coord(e['bi'],e['x']),t=e['t'] if ok else None,notas=e['notas'],bi=e['bi'],lig=False))
        for l in lig:
            if l['nota'].get('altura') is None or l['nota'].get('gracia'): continue
            items.append(dict(L=coord(l['bi'],l['x']),t=None,notas=[l['nota']],bi=l['bi'],lig=True))
        items.sort(key=lambda r: r['L'])
        # tiempos medidos crecientes; lo que rompe el orden se trata como no medido
        last=-1
        for r in items:
            if r['t'] is not None:
                if r['t']<=last+0.01: r['t']=None
                else: last=r['t']
        K=[i for i,r in enumerate(items) if r['t'] is not None]
        if len(K)<2: print('  ',parte,'sin ataques medidos suficientes'); continue
        Lm=np.array([items[i]['L'] for i in K]); Tm=np.array([items[i]['t'] for i in K])
        pend=float(np.median(np.diff(Tm)/np.maximum(np.diff(Lm),1e-6)))
        nint=0
        for i,r in enumerate(items):
            r['medido']=r['t'] is not None
            if r['medido']: continue
            j=np.searchsorted(Lm,r['L'])
            if j==0: t=Tm[0]-(Lm[0]-r['L'])*pend; base=Tm[0]
            elif j==len(Lm): t=Tm[-1]+(r['L']-Lm[-1])*pend; base=Tm[-1]
            else:
                f=(r['L']-Lm[j-1])/max(Lm[j]-Lm[j-1],1e-6); t=Tm[j-1]+f*(Tm[j]-Tm[j-1]); base=Tm[j-1]
            r['t']=base+round((t-base)/g)*g; nint+=1
        # filas por nota
        F=[]
        for r in items:
            for n in r['notas']:
                if n.get('altura') is None: continue
                F.append(dict(parte=PN[parte],compas=bars[r['bi']]['num'],t=float(r['t']),altura=n['altura']+n.get('bend',0.0),cuerda=n['cuerda']+1,
                              traste=n['traste'],bend=n.get('bend',0.0),ligada=r['lig'],armonico=bool(n.get('armonico')),medido=r['medido']))
        F.sort(key=lambda f:(f['t'],f['cuerda']))
        # duraciones
        ts=sorted(set(round(f['t'],4) for f in F)); tt,rms=W[parte]['t'],W[parte]['rms']
        for f in F:
            k=np.searchsorted(ts,round(f['t'],4)+1e-4); fin=ts[k] if k<len(ts) else f['t']+4*u
            a=np.searchsorted(tt,f['t']+0.02); b=np.searchsorted(tt,fin)
            if b>a+3:
                r=rms[a:b]; low=np.where(r<r[:3].max()*0.1)[0]
                if len(low): fin=min(fin,float(tt[a+low[0]]))
            f['dur']=max(g,fin-f['t'])
        # ligados sin cambio de altura: se suman a la nota anterior de la misma cuerda
        ult={}; keep=[]
        for f in F:
            cu=f['cuerda']
            if f['ligada'] and cu in ult and abs(ult[cu]['altura']-f['altura'])<0.01:
                ult[cu]['dur']=max(ult[cu]['dur'],f['t']+f['dur']-ult[cu]['t']); continue
            keep.append(f); ult[cu]=f
        filas+=keep
        info[PN[parte]]=dict(notas=len(keep),medidas=sum(f['medido'] for f in keep),interpoladas=nint)
    return filas,info,u

if __name__=='__main__':
    for c in sys.argv[1:]:
        filas,info,u=construir(c)
        filas.sort(key=lambda f:(f['t'],f['parte'],-f['altura']))
        with open(f'{c}_pistas.csv','w',newline='',encoding='utf-8') as fh:
            w=csv.writer(fh); w.writerow(['parte','compas','inicio_s','duracion_s','altura','cuerda','traste','bend','ligada','armonico','ataque_medido'])
            for f in filas:
                w.writerow([f['parte'],f['compas'],f'{f["t"]:.4f}',f'{f["dur"]:.4f}',f'{f["altura"]:g}',f['cuerda'],f['traste'],f'{f["bend"]:g}',int(f['ligada']),int(f['armonico']),int(f['medido'])])
        tot=sum(v['notas'] for v in info.values()); med=sum(v['medidas'] for v in info.values())
        print(c,'notas',tot,'con ataque medido %.0f %%'%(100*med/tot),info)
