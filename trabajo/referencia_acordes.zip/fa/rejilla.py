import sys, pickle, numpy as np, collections

def rejilla(c, verbose=True):
    A=pickle.load(open(f'par_{c}.pkl','rb'))
    t=np.array(sorted(e['t'] for p in A.values() for e in p['ev'] if 't' in e and e['c']<1.0))
    best=None
    for u in np.arange(0.050,0.200,0.00002):
        ph=np.angle(np.mean(np.exp(2j*np.pi*t/u)))/(2*np.pi)*u; r=(t-ph)/u; res=np.abs(r-np.round(r))
        sc=np.mean(res<0.12)
        if best is None or sc>best[0]+0.002: best=(sc,u,ph)
    sc,u,ph=best
    if verbose:
        print(c,'unidad %.5f s (negra = %.1f si es semicorchea)'%(u,60/(4*u)),'fase %.4f'%ph,'en rejilla %.1f %%'%(100*sc))
        r=(t-ph)/u; res=r-np.round(r)
        for a in range(0,int(t[-1]),40):
            m=(t>=a)&(t<a+40)
            if m.sum(): print('   %3d-%3d s: n=%4d en rejilla %.0f %%, desvío mediano %+.3f'%(a,a+40,m.sum(),100*np.mean(np.abs(res[m])<0.12),np.median(res[m])))
    return u,ph
if __name__=='__main__':
    for c in sys.argv[1:]: rejilla(c)
