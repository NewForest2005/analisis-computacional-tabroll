from comun import *
import sys; sys.path.insert(0,'../yz'); import yin as Y
from pathlib import Path
import tabroll.evaluation.melodia as MM
MM.REFS=Path('refs_cons').resolve()
J,cyc,hi,lo,al=load('fabienk'); al=MM.Alignment('fabienk')
gu=MM.mapped(al,al.ref['guitars'],known_only=False); sh=MM.calib(MM.top_line(MM.mapped(al,al.ref['guitars'])),hi)
ba=MM.mapped(al,al.ref['basses'],known_only=False)
secs=al.ref['sections']
A,B=float(sys.argv[1]),float(sys.argv[2])
for k,s in enumerate(secs):
    print(k,s[-1] if isinstance(s[-1],str) else s, end=' | ')
print()
names={k:s for k,s in enumerate(secs)}
for part in ('G1','G2'):
    print(part,[(round(n['t']+sh,2),n['p'],n['sec']) for n in gu if n['part']==part and A<=n['t']+sh<B])
print('B',[(round(n['t']+sh,2),n['p'],n['sec']) for n in ba if A<=n['t']+sh<B])
print('cuaderno alto',[(round(n[0],2),n[2]) for n in hi if A<=n[0]<B])
print('cuaderno bajo',[(round(n[0],2),n[2]) for n in lo if A<=n[0]<B])
Y.SR=22050
for nm in ('gtr','bass'):
    x=np.fromfile(f'fabienk.{nm}.f32',np.float32); seg=x[int(A*22050):int(B*22050)]
    tt,f0,cf,rms=Y.yin(seg,frame=2048,hop=256,fmin=38 if nm=='bass' else 70,fmax=300 if nm=='bass' else 1400,thr=0.2)
    m=69+12*np.log2(f0/440)-J['off']; out=[]
    for a in np.arange(0,B-A,0.1):
        k=(tt>=a)&(tt<a+0.1)&(cf>0.6)
        out.append(f'{A+a:.1f}:'+(f'{np.median(m[k]):.1f}' if k.sum()>=3 else '--'))
    print(nm,' '.join(out))
