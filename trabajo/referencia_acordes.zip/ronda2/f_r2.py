from comun import *
from pathlib import Path
import tabroll.evaluation.melodia as MM
orig=MM.REFS
for tag,d in (('antes (conservador)','refs_cons'),('ronda 2','refs_r2'),('main','main')):
    MM.REFS=Path(d).resolve() if d!='main' else Path('../main/references').resolve()
    for song in ('sarniezz','mata_zyklek','fabienk'):
        J=json.load(open(glob.glob(R+SONGS[song]+'/line_diagnostics.json')[0]))
        r=MM.evaluate(song, MM._notes(J['raw_high']), MM._notes(J['raw_bass']))
        print(tag,song,{k:round(r[k],1) for k in ('principal','principal_sin_octava','mas_aguda','bajo')},r['notas_principal'])
