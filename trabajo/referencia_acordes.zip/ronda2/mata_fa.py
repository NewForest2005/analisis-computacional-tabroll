from comun import *
import sys; sys.path.insert(0,'../yz'); import yin as Y
from pathlib import Path
import tabroll.evaluation.melodia as MM
MM.REFS=Path('refs_r2').resolve()
J,cyc,hi,lo,al=load('mata_zyklek'); al=MM.Alignment('mata_zyklek')
gu=MM.mapped(al,al.ref['guitars']); sh=MM.calib(MM.top_line(gu),hi); q=60/186
x=np.fromfile('mata_zyklek.gtr.f32',np.float32); Y.SR=22050
for bar in (32,64,120,224,232):
    t0=float(al.t((bar-1)*5*q))+sh; t1=float(al.t(bar*5*q))+sh
    print(f'--- compás {bar}: audio {t0:.2f}-{t1:.2f} s (off={J["off"]})')
    print('  cuaderno raw_high:',[(round(n[0]-t0,2),round(n[2],1)) for n in hi if t0-0.4<=n[0]<t1])
    print('  referencia:',[(round(n["t"]+sh-t0,2),n['p'],n['part']) for n in gu if t0-0.4<=n['t']+sh<t1])
    seg=x[int((t0-0.4)*22050):int(t1*22050)]
    tt,f0,cf,rms=Y.yin(seg,frame=2048,hop=256,fmin=70,fmax=1400,thr=0.2)
    m=69+12*np.log2(f0/440)-J['off']
    out=[]
    for a in np.arange(-0.4,t1-t0,0.1):
        k=(tt-0.4>=a)&(tt-0.4<a+0.1)&(cf>0.6)
        out.append(f'{a:.1f}:'+(f'{np.median(m[k]):.1f}' if k.sum()>=3 else '--')+f'({20*np.log10(rms[(tt-0.4>=a)&(tt-0.4<a+0.1)].mean()+1e-9):.0f})')
    print('  YIN guitarra:',' '.join(out))
