# Trabajo del 14-nov (tarde): segunda ronda, cierre de Yor Zarad y referencia de acordes completa

Scripts de trabajo temporal. Tienen rutas de la máquina donde se corrieron; sirven para ver cómo se hizo cada cosa.

## fa/ — referencia de acordes completa (fase A), en este orden
1. `leer_pdf.py`: lee la tablatura de los PDF por pista (usa `pdftab.py` de `trabajo_13nov.zip`).
2. `wav_feats.py`: ataques y altura (YIN) de cada WAV por pista de Guitar Pro; guarda la mezcla de guitarras y bajo.
3. `emparejar.py`: empareja los ataques del PDF con los del WAV de su pista (usa `alinear_wav.py` de `trabajo_13nov.zip`).
4. `tabla.py`: tabla de notas de todas las pistas en el tiempo del render → `<canción>_pistas.csv`.
5. `alinear_real.py`: DTW del render con la grabación oficial. `afinar_ref.py`: afina el mapa con las notas que comparte
   con la referencia corregida → `<canción>_pistas_alineacion_fina.json`.
6. `validar.py` y `difs.py`: cuántas notas de la referencia corregida están también en Guitar Pro, y en qué difieren.
7. `unir.py`: escribe `references/completas/`. `medir.py`: la armonía del cuaderno contra las tres referencias
   (`referencias_resultado.json`).
`rejilla.py` y `compases_fa.py` buscan la unidad rítmica del render y el inicio de los compases (solo diagnóstico).

## ronda2/
`f_r2.py`: la F antes y después de la segunda ronda. `mata_fa.py`: la altura de la pista de guitarra en los compases
con silencio de Mata Zyklek (el Fa agudo del c. 64). `fab_fin.py`: el pasaje del final del clip 21 de Fabienk.
