"""Arma el corpus de referencia a partir de los materiales del usuario (Lo_que_sigue.zip): progresiones por tema de 9
álbumes, catálogo de 20 progresiones (MIDI), línea base pop, métricas de Hooktheory y 4 ejemplos de jazz (TheoryTab)."""
import json, csv, re, collections, math, os, shutil
OUT = '../corpus_referencia/'
R = json.load(open('albumes.json'))
ALB = {'30 - Adele': ('30', 'Adele', 2021), 'Everything to Everyone - Rene Rapp': ('Everything to Everyone', 'Reneé Rapp', 2022),
       "Gettin' Old - Luke Combs": ("Gettin' Old", 'Luke Combs', 2023), 'Happier Than Ever - Billie Ellish': ('Happier Than Ever', 'Billie Eilish', 2021),
       'Midnights - Taylor Swift': ('Midnights', 'Taylor Swift', 2022), 'Montero - Lil nas X': ('Montero', 'Lil Nas X', 2021),
       'Solar Powder - Lorde': ('Solar Power', 'Lorde', 2021), 'Substract - Ed Sheeran': ('− (Subtract)', 'Ed Sheeran', 2023),
       'Think Later - Tate Mcrae': ('Think Later', 'Tate McRae', 2023)}
COLOR = {(0.98, 0.0, 0.01): 1, (0.97, 0.0, 0.01): 1, (0.98, 0.69, 0.08): 2, (0.94, 0.9, 0.01): 3, (0.93, 0.9, 0.01): 3, (0.23, 0.83, 0.0): 4,
         (0.23, 0.82, 0.0): 4, (0.28, 0.14, 1.0): 5, (0.72, 0.12, 0.9): 6, (0.71, 0.12, 0.89): 6, (0.97, 0.11, 0.8): 7}
ROM = re.compile(r'^([♭♯]?)(VII|VI|IV|V|III|II|I|vii|vi|iv|v|iii|ii|i)(.*)$')
def partes(c):
    m = ROM.match(c)
    if not m: return None
    alt, rom, resto = m.groups()
    aplicado = ''
    if '/' in resto:
        resto, aplicado = resto.split('/', 1)
    inv = ''
    if '^6_4' in resto or '^64' in resto: inv = '64'
    elif '^4_2' in resto: inv = '42'
    elif '^4_3' in resto or '^43' in resto: inv = '43'
    elif '^6_5' in resto: inv = '65'
    elif '⁶' in resto or re.search(r'\^6(?!\d)', resto): inv = '6'
    septima = ('⁷' in resto or '^7' in resto or inv in ('42', '43', '65') or '⁹' in resto or '^11' in resto)
    prest = re.search(r'\((mix|min|lyd|dor|phr|maj|loc)\)', resto)
    sus = re.search(r'sus[24]', resto); add = re.search(r'\(add\d+\)', resto)
    return dict(base=alt + rom + ('°' if '°' in resto else ''), aplicado=aplicado, inversion=inv, septima=septima,
                prestado=prest.group(1) if prest else '', sus=sus.group(0) if sus else '', add=add.group(0) if add else '')
filas = []; dist = {}; trans = {}
for key, d in R.items():
    alb, art, anio = ALB[key]
    for n, t in enumerate(d['temas'], 1):
        P = [partes(c) for c in t['acordes']]
        bases = [p['base'] + ('/' + p['aplicado'] if p and p['aplicado'] else '') if p else '?' for p in P]
        tonica_menor = any(b == 'i' for b in bases) or (not any(b == 'I' for b in bases) and any(b in ('III', 'VI', 'VII') for b in bases))
        if not tonica_menor:                                  # en mayor, «VII» mayúscula es ♭VII (el PDF perdió el bemol en algunos álbumes)
            bases = ['♭VII' if b == 'VII' else b for b in bases]
        bajo = [COLOR.get(tuple(c), '') for c in t['colores']]
        filas.append(dict(album=alb, artista=art, anio=anio, n=n, tema=t['tema'], modo='menor' if tonica_menor else 'mayor',
                          acordes=' '.join(t['acordes']), acordes_base=' '.join(bases),
                          bajo_grados=' '.join(str(b) for b in bajo) if len(bajo) == len(bases) else '',
                          n_acordes=len(bases), con_septima=sum(bool(p and p['septima']) for p in P), invertidos=sum(bool(p and p['inversion']) for p in P),
                          prestados=sum(bool(p and p['prestado']) for p in P), aplicados=sum(bool(p and p['aplicado']) for p in P),
                          sus_add=sum(bool(p and (p['sus'] or p['add'])) for p in P)))
        cnt = dist.setdefault((alb, art), collections.Counter()); tr = trans.setdefault((alb, art), collections.Counter())
        modo = 'm:' if tonica_menor else 'M:'
        for b in bases: cnt[modo + b] += 1
        for a, b in zip(bases, bases[1:] + bases[:1]):                  # bucle: el último vuelve al primero
            if a != b: tr[modo + a + '→' + b] += 1
os.makedirs(OUT, exist_ok=True)
with open(OUT + 'albumes_progresiones.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(filas[0])); w.writeheader(); w.writerows(filas)
# frecuencias por álbum (en % de acordes) y total
tot = collections.Counter(); ttr = collections.Counter()
for c in dist.values(): tot.update(c)
for c in trans.values(): ttr.update(c)
grados = [g for g, _ in tot.most_common()]
with open(OUT + 'albumes_frecuencia_acordes.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['album', 'artista', 'n_acordes'] + grados)
    for (alb, art), c in dist.items():
        s = sum(c.values()); w.writerow([alb, art, s] + [round(100 * c[g] / s, 1) for g in grados])
    s = sum(tot.values()); w.writerow(['TODOS', '', s] + [round(100 * tot[g] / s, 1) for g in grados])
with open(OUT + 'albumes_transiciones.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['transicion', 'total', 'albumes_que_la_usan'] + [a for a, _ in dist])
    for t, n in ttr.most_common():
        w.writerow([t, n, sum(1 for c in trans.values() if c[t])] + [trans[k][t] for k in dist])
# parecido entre álbumes: Jensen-Shannon de la distribución de acordes (0 = iguales, 1 = sin nada en común)
def js(p, q):
    ks = set(p) | set(q); sp, sq = sum(p.values()), sum(q.values()); d = 0
    for k in ks:
        a, b = p[k] / sp, q[k] / sq; m = (a + b) / 2
        if a: d += 0.5 * a * math.log2(a / m)
        if b: d += 0.5 * b * math.log2(b / m)
    return d
ks = list(dist)
with open(OUT + 'albumes_parecido_js.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow([''] + [a for a, _ in ks])
    for k in ks: w.writerow([k[0]] + [round(js(dist[k], dist[j]), 3) for j in ks])
# progresiones compartidas: bucles normalizados por rotación
def canon(bases):
    rots = [tuple(bases[i:] + bases[:i]) for i in range(len(bases))]; return min(rots)
comp = collections.defaultdict(list)
for r in filas:
    b = r['acordes_base'].split()
    b = [x for i, x in enumerate(b) if i == 0 or x != b[i - 1]]
    if 2 <= len(b) <= 5: comp[(r['modo'], canon(b))].append(f"{r['artista']} – {r['tema']}")
with open(OUT + 'albumes_progresiones_compartidas.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['modo', 'progresion_canonica (rotación mínima)', 'n_temas', 'temas'])
    for (modo, c), v in sorted(comp.items(), key=lambda kv: -len(kv[1])):
        if len(v) >= 2: w.writerow([modo, ' '.join(c), len(v), ' | '.join(v)])
# jazz
print('temas', len(filas), 'acordes', sum(tot.values()))
print('top acordes:', [(g, round(100 * n / sum(tot.values()), 1)) for g, n in tot.most_common(14)])
print('top transiciones:', ttr.most_common(12))
print('modo:', collections.Counter(r['modo'] for r in filas))
tA = sum(r['n_acordes'] for r in filas)
print('séptima %.1f%% invertidos %.1f%% prestados %.1f%% aplicados %.1f%% sus/add %.1f%%' % tuple(100 * sum(r[k] for r in filas) / tA for k in ('con_septima', 'invertidos', 'prestados', 'aplicados', 'sus_add')))
print('compartidas:', [(m, ' '.join(c), len(v)) for (m, c), v in sorted(comp.items(), key=lambda kv: -len(kv[1]))[:8]])
print('sin reconocer:', [c for d in R.values() for t in d['temas'] for c in t['acordes'] if not partes(c)])
