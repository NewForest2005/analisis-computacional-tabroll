import re, sys
def rtf2txt(path):
    s = open(path, 'rb').read().decode('cp1252', 'replace')
    # hyperlinks: keep visible text
    s = re.sub(r'\{\\\*\\fldinst\{HYPERLINK "([^"]*)"\}\}', '', s)
    s = re.sub(r"\\u(-?\d+) ?\??", lambda m: chr(int(m.group(1)) % 65536), s)
    s = re.sub(r"\\'([0-9a-f]{2})", lambda m: bytes([int(m.group(1), 16)]).decode('cp1252', 'replace'), s)
    s = re.sub(r'\{\\(fonttbl|colortbl|\*\\expandedcolortbl|\*\\listtable|\*\\listoverridetable)[^\n]*', '', s)
    s = re.sub(r'\{\{\\NeXTGraphic ([^\\]+?) \\width[^}]*\}[^}]*\}', r'[IMG: \1]', s)
    s = s.replace('\\\n', '\n').replace('\\par', '\n')
    s = re.sub(r'\\[a-zA-Z]+-?\d* ?', '', s)
    s = re.sub(r'[{}]', '', s)
    s = re.sub(r'\n\s*\n+', '\n\n', s)
    return s
if __name__ == '__main__':
    print(rtf2txt(sys.argv[1]))
