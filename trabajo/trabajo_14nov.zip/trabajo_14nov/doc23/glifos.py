"""Decodifica los cifrados de los PDF de álbumes: la fuente Minion va con codificación propia; los nombres de glifo están
en /Differences del diccionario de la fuente (o en el CFF)."""
import pikepdf, glob, sys, io
from fontTools.cffLib import CFFFontSet
def mapa(pdf_path):
    pdf = pikepdf.open(pdf_path); out = {}
    for page in pdf.pages:
        fonts = page.Resources.get('/Font', {})
        for k, f in fonts.items():
            name = str(f.get('/BaseFont', ''))
            m = {}
            enc = f.get('/Encoding')
            if enc is not None and not isinstance(enc, pikepdf.Name) and '/Differences' in enc:
                code = None
                for x in enc['/Differences']:
                    if isinstance(x, pikepdf.Name): m[code] = str(x)[1:]; code += 1
                    else: code = int(x)
            out[name] = m
    return out
if __name__ == '__main__':
    for f in sorted(glob.glob('../lo_que_sigue/z_Chord analyses*/*/*.pdf'))[:2]:
        for name, m in mapa(f).items():
            if 'Minion' in name: print(f.split('/')[-1], name, m)
