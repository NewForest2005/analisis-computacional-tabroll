"""Progresión por tema de los 9 PDF de álbumes (Hooktheory): cifrado (fuente Minion con codificación propia) y color del
círculo (grado del bajo)."""
import pdfplumber, pikepdf, glob, re, json, collections, os
ESP = {401: '⁶', 402: '⁷', 404: '⁹', 399: '⁴', 397: '²', 440: '(', 439: ')', 491: '9', 125: '°'}
def gid2chr(g):
    if g in ESP: return ESP[g]
    if g <= 59: return chr(g + 31)
    if g < 95: return chr(g + 33)
    return f'<{g}>'
def mapa(pdf_path):
    pdf = pikepdf.open(pdf_path); m = {}
    for page in pdf.pages:
        for k, f in page.Resources.get('/Font', {}).items():
            if 'Minion' not in str(f.get('/BaseFont', '')): continue
            code = None
            for x in f['/Encoding']['/Differences']:
                if isinstance(x, pikepdf.Name): m[code] = gid2chr(int(str(x)[4:])); code += 1
                else: code = int(x)
    return m
def parse(path):
    m = mapa(path); p = pdfplumber.open(path).pages[0]
    ws = p.extract_words(extra_attrs=['fontname', 'size'], keep_blank_chars=True, x_tolerance=1.5)
    cab = ' '.join(w['text'] for w in ws if 'Montserrat' in w['fontname'] and w['size'] > 20)
    # títulos de tema
    tw = [w for w in ws if 'Montserrat' in w['fontname'] and w['size'] < 15 and not w['text'].strip().isdigit()
          and 'HOOKTHEORY' not in w['text'].upper() and 'AMAZING' not in w['text'].upper()]
    filas = collections.defaultdict(list)
    for w in tw: filas[round(w['top'])].append(w)
    lineas = sorted((y, ' '.join(x['text'].strip() for x in sorted(v, key=lambda x: x['x0']))) for y, v in filas.items())
    tracks = []
    for y, txt in lineas:
        if tracks and y - tracks[-1]['y1'] < 17: tracks[-1]['name'] += ' ' + txt; tracks[-1]['y1'] = y
        else: tracks.append(dict(y0=y, y1=y, name=txt))
    # cifrados
    toks = []
    for w in ws:
        if 'Minion' in w['fontname']:
            t = ''.join(m.get(int(c), '?') for c in re.findall(r'\(cid:(\d+)\)', w['text']))
        elif 'Arial' in w['fontname']:
            t = w['text']
        else: continue
        toks.append(dict(x=w['x0'], x1=w['x1'], y=w['top'], yb=w['bottom'], size=w['size'], t=t))
    if not toks: return cab, []
    big = max(t['size'] for t in toks); main = [t for t in toks if t['size'] >= 0.75 * big]; sub = [t for t in toks if t['size'] < 0.75 * big]
    # filas de acordes
    rows = []
    for t in sorted(main, key=lambda t: (t['y'], t['x'])):
        if rows and abs(t['y'] - rows[-1][0]['y']) < 4: rows[-1].append(t)
        else: rows.append([t])
    circ = [c for c in p.curves if 5 < (c['x1'] - c['x0']) < 30 and abs((c['x1'] - c['x0']) - (c['bottom'] - c['top'])) < 1.5 and c.get('non_stroking_color')]
    out = collections.OrderedDict((i, dict(tema=t['name'].title(), acordes=[], colores=[])) for i, t in enumerate(tracks))
    for row in rows:
        row.sort(key=lambda t: t['x']); y = row[0]['y']
        chords = []
        for t in row:
            if chords and t['x'] - chords[-1]['x1'] < 0.35 * big: chords[-1]['t'] += t['t']; chords[-1]['x1'] = t['x1']
            else: chords.append(dict(x=t['x'], x1=t['x1'], t=t['t'], y=t['y'], yb=t['yb']))
        for s in sorted(sub, key=lambda s: s['x']):
            if not (y - big < s['y'] < y + 1.6 * big): continue
            c = [c for c in chords if c['x'] - 1 <= s['x'] <= c['x1'] + 2.2 * big]
            if c:
                cc = max(c, key=lambda c: c['x']); arriba = (s['y'] + s['yb']) / 2 < (cc['y'] + cc['yb']) / 2
                cc['t'] += ('^' if arriba else '_') + s['t']
        # tema: el título cuyo centro está más cerca por arriba de la fila (los círculos van a la altura del título)
        cand = [i for i, t in enumerate(tracks) if t['y0'] - 12 <= y]
        if not cand: continue
        i = max(cand, key=lambda i: tracks[i]['y0'])
        cs = sorted([c for c in circ if y - 3.2 * big < c['top'] < y and chords[0]['x'] - 3 * big < c['x0'] < chords[-1]['x1'] + 3 * big], key=lambda c: c['x0'])
        out[i]['acordes'] += [re.sub(r'\^(?=[\^_]|$)', '', c['t']).replace(')add9(', '(add9)') for c in chords]
        dd = []
        for c in cs:                                          # cada círculo puede venir dibujado dos veces
            if not dd or c['x0'] - dd[-1]['x0'] > 2: dd.append(c)
        out[i]['colores'] += [tuple(round(v, 2) for v in c['non_stroking_color']) for c in dd]
    return cab, [o for o in out.values() if o['acordes']]
if __name__ == '__main__':
    R = {}
    for f in sorted(glob.glob('../lo_que_sigue/z_Chord analyses*/*/*.pdf')):
        t, out = parse(f); R[os.path.basename(f)[:-4]] = dict(cabecera=t, temas=out)
        print('==', os.path.basename(f), '|', t, '|', len(out), 'temas')
        for o in out: print('   %-30s %s  [%d círculos]' % (o['tema'][:30], ' – '.join(o['acordes']), len(o['colores'])))
    json.dump(R, open('albumes.json', 'w'), ensure_ascii=False)
