"""Name chords from midi_chords.json as Roman numerals in C major (key sig 0)."""
import json, sys, re
NAMES = ['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B']
QUAL = {  # intervals from root -> (suffix, roman case)
    frozenset([0,4,7]): ('', 'M'), frozenset([0,3,7]): ('m', 'm'),
    frozenset([0,3,6]): ('dim', 'd'), frozenset([0,4,8]): ('aug', 'M'),
    frozenset([0,4,7,10]): ('7', 'M'), frozenset([0,3,7,10]): ('m7', 'm'),
    frozenset([0,4,7,11]): ('maj7', 'M'), frozenset([0,3,6,10]): ('m7b5', 'd'),
}
DEG = {0:'I',1:'bII',2:'II',3:'bIII',4:'III',5:'IV',6:'#IV',7:'V',8:'bVI',9:'VI',10:'bVII',11:'VII'}
def name(pitches):
    pcs = set(p % 12 for p in pitches); bass = min(pitches) % 12
    for r in range(12):
        iv = frozenset((p - r) % 12 for p in pcs)
        if iv in QUAL:
            suf, case = QUAL[iv]
            rn = DEG[r]
            base = rn.lstrip('b#'); acc = rn[:len(rn)-len(base)]
            if case in 'md': base = base.lower()
            rn = acc + base + ('°' if case == 'd' else '')
            seventh = len(iv) == 4
            bi = (bass - r) % 12
            third = 3 if 3 in iv else 4
            fifth = 6 if 6 in iv else (8 if 8 in iv else 7)
            if seventh:
                inv = {0:'7', third:'65', fifth:'43', 10:'42', 11:'42'}[bi]
            else:
                inv = {0:'', third:'6', fifth:'64'}[bi]
            sym = NAMES[r] + suf + ('' if bi == 0 else '/' + NAMES[bass])
            return sym, rn + inv
    return '?', '?'
d = json.load(open(sys.argv[1]))
for f, chords in d.items():
    code = f.split('TTCP - ')[-1].replace('.mid', '')
    syms = [name(c['pitches']) for c in chords]
    print(f"{f.split(' - ')[0]:38s} [{code}] ", ' | '.join(s for s, _ in syms), '  =>  ', ' - '.join(r for _, r in syms))
