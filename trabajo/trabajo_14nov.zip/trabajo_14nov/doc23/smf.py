"""Minimal pure-Python SMF parser: prints notes grouped into chords per onset."""
import sys, os, glob, struct, json

NAMES = ['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B']

def vlq(data, i):
    v = 0
    while True:
        b = data[i]; i += 1
        v = (v << 7) | (b & 0x7F)
        if not b & 0x80:
            return v, i

def parse(path):
    data = open(path, 'rb').read()
    assert data[:4] == b'MThd', path
    hlen = struct.unpack('>I', data[4:8])[0]
    fmt, ntrk, div = struct.unpack('>HHH', data[8:14])
    i = 8 + hlen
    tracks = []
    meta = []
    for t in range(ntrk):
        assert data[i:i+4] == b'MTrk'
        ln = struct.unpack('>I', data[i+4:i+8])[0]
        tr = data[i+8:i+8+ln]; i += 8 + ln
        j = 0; tick = 0; status = None
        on = {}; notes = []
        while j < len(tr):
            d, j = vlq(tr, j); tick += d
            b = tr[j]
            if b == 0xFF:
                typ = tr[j+1]; ln2, k = vlq(tr, j+2)
                payload = tr[k:k+ln2]; j = k + ln2
                meta.append((t, tick, hex(typ), payload.hex() if typ not in (1,2,3,4,5,6) else payload.decode('latin1')))
                continue
            if b in (0xF0, 0xF7):
                ln2, k = vlq(tr, j+1); j = k + ln2; continue
            if b & 0x80:
                status = b; j += 1
            hi = status & 0xF0
            if hi in (0xC0, 0xD0):
                j += 1; continue
            a1, a2 = tr[j], tr[j+1]; j += 2
            ch = status & 0x0F
            if hi == 0x90 and a2 > 0:
                on.setdefault((ch, a1), []).append((tick, a2))
            elif hi == 0x80 or (hi == 0x90 and a2 == 0):
                if on.get((ch, a1)):
                    st, vel = on[(ch, a1)].pop(0)
                    notes.append((st, tick, a1, ch, vel))
        tracks.append(notes)
    return fmt, ntrk, div, tracks, meta

def nm(p):
    return f"{NAMES[p%12]}{p//12-1}"

if __name__ == '__main__':
    d = sys.argv[1]
    out = {}
    for f in sorted(glob.glob(os.path.join(d, '*.mid'))):
        fmt, ntrk, div, tracks, meta = parse(f)
        allnotes = sorted(n for tr in tracks for n in tr)
        groups = {}
        for st, en, p, ch, vel in allnotes:
            groups.setdefault(st, []).append((p, en - st))
        print('==', os.path.basename(f), f'fmt{fmt} ntrk{ntrk} div{div}')
        for m in meta:
            print('   meta', m)
        chords = []
        for st in sorted(groups):
            ps = sorted(groups[st])
            durs = sorted(set(x[1] for x in ps))
            print(f'   t={st/div:6.2f}q dur={[x/div for x in durs]} ', ' '.join(nm(p) for p, _ in ps), ' pcs:', sorted(set(p % 12 for p, _ in ps)))
            chords.append({'beat': st/div, 'durs': [x/div for x in durs], 'pitches': [p for p, _ in ps]})
        out[os.path.basename(f)] = chords
    json.dump(out, open(sys.argv[2], 'w'), indent=1)
