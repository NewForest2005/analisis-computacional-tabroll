"""Clips para verificar de oído la referencia de Yor Zarad contra la grabación: izquierda, guitarra + bajo reales
(Demucs, semilla 0); derecha, la referencia sintetizada (todas las partes). Sin usar nada del cuaderno."""
import sys, subprocess, csv, numpy as np
sys.path.insert(0, '../h3/base/src')
import tabroll.evaluation.melodia as M
SR = 22050; OUT = '../verif_yz_extra/'
al = M.Alignment('yor_zarad')
REF = al.ref['notes']                              # (inicio s, duración s, altura, parte) en tiempo de partitura
L = np.fromfile('real_guitar.f32', np.float32) + np.fromfile('real_bass.f32', np.float32)


def synth(ns, t0, dur):
    y = np.zeros(int(dur * SR), np.float32)
    for n in ns:
        a = int((n['t'] - t0) * SR); d = max(0.07, min(0.8 * (n['te'] - n['t']), n['te'] - n['t'] - 0.02))
        b = a + int(d * SR)
        if b <= 0 or a >= len(y): continue
        a2, b2 = max(a, 0), min(b, len(y)); tt = np.arange(b2 - a2) / SR + (a2 - a) / SR
        f = 440 * 2 ** ((n['p'] - 69) / 12)
        bajo = n['part'] == 'B'
        w = sum(np.sin(2 * np.pi * h * f * tt) / h ** (1.6 if bajo else 1.0) for h in (1, 2, 3, 4))
        env = np.minimum(1, tt / 0.008) * np.exp(-tt * (3.0 if bajo else 4.0)) * np.minimum(1, (d - tt) / 0.01)
        y[a2:b2] += (0.35 if bajo else 0.22) * w * env
    return y


def clip(nombre, A0, dur, off):
    """off: audio - partitura en este tramo (el tempo es el mismo: pendiente 1)."""
    l = L[int(A0 * SR):int((A0 + dur) * SR)]; l = l / (np.abs(l).max() + 1e-9) * 0.8
    ns = [dict(t=t + off, te=t + d + off, p=p, part=part) for t, d, p, part in REF if A0 - 1 <= t + off < A0 + dur]
    r = synth(ns, A0, (len(l) + 1) / SR); r = r / (np.abs(r).max() + 1e-9) * 0.6
    st = np.stack([l, r[:len(l)]], 1).astype(np.float32)
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-f', 'f32le', '-ar', str(SR), '-ac', '2', '-i', '-', '-b:a', '192k', OUT + nombre],
                   input=st.tobytes(), check=True)


import importlib.util
spec = importlib.util.spec_from_file_location('yz', '../h3/base/references/yor_zarad_partitura.py')
R = importlib.util.module_from_spec(spec); spec.loader.exec_module(R)
filas = []
for k, (b, motivo) in enumerate([(20, 'fin de B'), (48, 'fin de frase en D'), (60, 'fin de frase en D'), (76, 'fin de D'),
                                 (108, 'fin de E'), (132, 'fin de F'), (153, 'compás de 2/4 en H'), (201, 'último compás')], 13):
    c0, c1 = max(1, b - 1), min(201, b + 1)
    s0, s1 = R.inicio(c0) * R.S, R.inicio(c1 + 1) * R.S
    off = float(np.median([al.t(x) - x for x in np.linspace(s0, s1, 25)]))
    A0, A1 = s0 + off, s1 + off
    arch = f'{k:02d}_{int(A0 // 60)}m{int(A0 % 60):02d}s.mp3'
    clip(arch, A0 - 0.3, A1 - A0 + 0.6, off)
    sec = next(nm for nm, a, c, kn in R.SECTIONS if a <= b <= c)
    filas.append(dict(archivo=arch, seccion=sec, compases=f'{c0}-{c1}', minuto=f'{int(A0 // 60)}:{int(A0 % 60):02d}-{int(A1 // 60)}:{int(A1 % 60):02d}',
                      coincide='', diferencias='', melodia_principal='(no hace falta)', comentario=''))
    print(arch, b, motivo, round(A0, 2), round(A1, 2))
with open(OUT + 'respuestas_yz_extra.csv', 'w', newline='', encoding='utf-8-sig') as fh:
    w = csv.DictWriter(fh, fieldnames=list(filas[0]), delimiter=';'); w.writeheader(); w.writerows(filas)
