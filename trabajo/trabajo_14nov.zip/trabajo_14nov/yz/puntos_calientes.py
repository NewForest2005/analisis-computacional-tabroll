"""Compases donde la referencia explica peor la grabación: croma de cuartos de tono de la referencia sintetizada (alturas
exactas) frente a guitarra + bajo reales, compás por compás, con la alineación afinada. No usa nada del cuaderno."""
import sys, numpy as np, importlib.util, json
sys.path.insert(0, '../h3/base/src')
import tabroll.evaluation.melodia as M
import dtw as D
SR = 22050
spec = importlib.util.spec_from_file_location('yz', '../h3/base/references/yor_zarad_partitura.py')
R = importlib.util.module_from_spec(spec); spec.loader.exec_module(R)
al = M.Alignment('yor_zarad')
ref = al.ref['notes']
real = np.fromfile('real_guitar.f32', np.float32) + np.fromfile('real_bass.f32', np.float32)
# referencia sintetizada en tiempo de partitura (alturas exactas, sin el desafinado del render)
dur = R.inicio(202) * R.S + 2
y = np.zeros(int(dur * SR), np.float32)
for t, d, p, part in ref:
    a = int(t * SR); n = int(min(d, 2.0) * SR)
    if n < 10: continue
    tt = np.arange(n) / SR; f = 440 * 2 ** ((p - 69) / 12)
    y[a:a + n] += (sum(np.sin(2 * np.pi * h * f * tt) / h for h in (1, 2, 3, 4)) * np.exp(-tt * 2.0) * np.minimum(1, tt / 0.01)).astype(np.float32)
Cr = D.croma24(y); Ca = D.croma24(real)
# afinación global de la grabación: rotación fina de la croma (en cuartos de tono no alcanza; se mide en el audio)
dt = D.DT
filas = []
for b in range(1, 202):
    s0, s1 = R.inicio(b) * R.S, R.inicio(b + 1) * R.S
    i = np.arange(int(s0 / dt), int(s1 / dt))
    j = np.round(np.array([al.t(x) for x in i * dt]) / dt).astype(int)
    ok = (j >= 0) & (j < len(Ca)) & (i < len(Cr))
    if ok.sum() < 3: continue
    sim = float(np.mean(np.sum(Cr[i[ok]] * Ca[j[ok]], axis=1)))
    sec = next(nm for nm, a, c, k in R.SECTIONS if a <= b <= c)
    filas.append((b, sec, sim, float(al.t(s0))))
sims = np.array([f[2] for f in filas])
print('similitud media %.3f, mediana %.3f' % (sims.mean(), np.median(sims)))
# z dentro de cada sección
out = []
for sec in dict.fromkeys(f[1] for f in filas):
    v = np.array([f[2] for f in filas if f[1] == sec]); med = np.median(v); mad = np.median(np.abs(v - med)) + 1e-3
    for f in filas:
        if f[1] == sec:
            out.append(dict(compas=f[0], seccion=sec, sim=round(f[2], 3), z=round((f[2] - med) / mad, 1), t_audio=round(f[3], 2)))
json.dump(out, open('puntos_calientes.json', 'w'), ensure_ascii=False)
peores = sorted(out, key=lambda r: r['z'])[:20]
for r in peores: print(r)
for sec in dict.fromkeys(r['seccion'] for r in out):
    v = [r['sim'] for r in out if r['seccion'] == sec]; print('%-50s media %.3f min %.3f' % (sec[:50], np.mean(v), min(v)))
